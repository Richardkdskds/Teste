import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}"],
  theme: { extend: { colors: { stark: "#e11d2e", silver: "#c0c6cf" } } },
  plugins: [],
} satisfies Config;
