"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { useVoice } from "./useVoice";
import { authFetch, wsUrl } from "./api";
import LoginGate, { logout } from "./LoginGate";
import MemoryPanel from "./MemoryPanel";
import MissionsPanel from "./MissionsPanel";
import ToolsPanel from "./ToolsPanel";

type Msg = { role: "user" | "jarvis"; text: string; ts: string; voice?: boolean; streaming?: boolean };
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const now = () => new Date().toLocaleTimeString("pt-BR");

export default function Home() {
  return (
    <LoginGate api={API}>
      <JarvisApp />
    </LoginGate>
  );
}

function JarvisApp() {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [online, setOnline] = useState<null | boolean>(null);
  const [aiReady, setAiReady] = useState(false);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceURI, setVoiceURI] = useState("");
  const [volume, setVolume] = useState(1);
  const [notes, setNotes] = useState<string[]>([]);
  const [tab, setTab] = useState<"tasks" | "memory" | "tools" | "voice" | "notes" | "settings">("tasks");
  const endRef = useRef<HTMLDivElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const speakRef = useRef<(t: string) => void>(() => {});
  const fullRef = useRef("");
  const [thinking, setThinking] = useState(false);
  const [memTick, setMemTick] = useState(0);
  const [voiceHist, setVoiceHist] = useState<string[]>([]);
  const [silenceMs, setSilenceMs] = useState(1500);
  const histLoaded = useRef(false);

  const notify = (t: string) => setNotes((n) => [`${now()} ${t}`, ...n].slice(0, 30));

  useEffect(() => {
    const check = async () => {
      try {
        const r = await fetch(`${API}/health`);
        const j = await r.json();
        setOnline(true); setAiReady(!!j.ai_configured);
      } catch { setOnline(false); setAiReady(false); }
    };
    check(); const id = setInterval(check, 10000); return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const load = () => {
      const v = window.speechSynthesis.getVoices();
      setVoices(v);
      setVoiceURI((cur) => cur || (v.find((x) => x.lang.startsWith("pt-BR"))?.voiceURI ?? ""));
    };
    load(); window.speechSynthesis.onvoiceschanged = load;
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const speak = useCallback((text: string) => {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "pt-BR"; u.volume = volume;
    const v = voices.find((x) => x.voiceURI === voiceURI); if (v) u.voice = v;
    u.onstart = () => setSpeaking(true); u.onend = () => setSpeaking(false);
    window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
  }, [voices, voiceURI, volume]);

  speakRef.current = speak;

  useEffect(() => {
    const id = setInterval(async () => {
      try {
        const due = await (await authFetch(API, "/api/reminders/due")).json();
        for (const r of due) {
          const text = `Senhor, lembrete: ${r.text}`;
          setMsgs((m) => [...m, { role: "jarvis", text, ts: now() }]); notify(text); speakRef.current(text);
          await authFetch(API, `/api/reminders/${r.id}/ack`, { method: "POST" });
        }
      } catch {}
    }, 15000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    let closed = false; let timer: any;
    const connect = () => {
      const ws = new WebSocket(wsUrl(API)); wsRef.current = ws;
      ws.onmessage = (ev) => {
        const m = JSON.parse(ev.data);
        if (m.type === "delta") {
          fullRef.current += m.text;
          setMsgs((cur) => {
            const last = cur[cur.length - 1];
            if (last && last.role === "jarvis" && last.streaming) return [...cur.slice(0, -1), { ...last, text: last.text + m.text }];
            return [...cur, { role: "jarvis", text: m.text, ts: now(), streaming: true }];
          });
        } else if (m.type === "done") {
          setThinking(false);
          setMsgs((cur) => cur.map((x, i) => (i === cur.length - 1 ? { ...x, streaming: false } : x)));
          speakRef.current(fullRef.current); fullRef.current = "";
        } else if (m.type === "memory_proposed") {
          notify(`Jarvis sugeriu ${m.count} memória(s). Veja na aba Memória.`); setMemTick((t) => t + 1);
        } else if (m.type === "error") {
          setThinking(false); fullRef.current = "";
          setMsgs((cur) => [...cur, { role: "jarvis", text: `Erro: ${m.message}`, ts: now() }]);
          notify(m.message);
        }
      };
      ws.onclose = () => { if (!closed) timer = setTimeout(connect, 3000); };
    };
    connect();
    return () => { closed = true; clearTimeout(timer); wsRef.current?.close(); };
  }, []);

  const send = useCallback((text: string, voice = false) => {
    const t = text.trim(); if (!t) return;
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) { notify("Sem conexão com o backend. Verifique se ele está rodando."); return; }
    window.speechSynthesis.cancel();
    setMsgs((m) => [...m, { role: "user", text: t, ts: now(), voice }]); setInput(""); setThinking(true);
    if (voice) setVoiceHist((h) => [`${now()} ${t}`, ...h].slice(0, 50));
    ws.send(JSON.stringify({ text: t }));
  }, []);

  useEffect(() => {
    try { const raw = localStorage.getItem("jarvis_voice_hist"); if (raw) setVoiceHist(JSON.parse(raw)); } catch {}
    histLoaded.current = true;
  }, []);
  useEffect(() => {
    if (!histLoaded.current) return;
    try { localStorage.setItem("jarvis_voice_hist", JSON.stringify(voiceHist)); } catch {}
  }, [voiceHist]);

  const voice = useVoice({ onFinal: (t) => send(t, true), onError: notify, speaking, silenceMs });
  const listening = voice.listening;

  const stopSpeech = () => { window.speechSynthesis.cancel(); setSpeaking(false); };

  const tabs = [["tasks", "Missões"], ["memory", "Memória"], ["tools", "Ferramentas"], ["voice", "Voz"], ["notes", "Alertas"], ["settings", "Config"]] as const;

  return (
    <main className="min-h-screen p-3 md:p-5 grid gap-3 lg:grid-cols-[1fr_340px]">
      <section className="grid gap-3 lg:grid-rows-[auto_1fr_auto]">
        <header className="panel px-4 py-2 flex items-center justify-between">
          <span className="tracking-[.35em] text-stark font-bold">J.A.R.V.I.S</span>
          <span className="text-xs flex gap-3">
            <span className={online ? "text-green-400" : "text-stark"}>
              ● Backend {online === null ? "…" : online ? "online" : "offline"}
            </span>
            <span className={aiReady ? "text-green-400" : "text-silver"}>● IA {aiReady ? "configurada" : "sem chave"}</span>
            <button onClick={logout} className="text-silver/60 hover:text-stark underline">Sair</button>
          </span>
        </header>

        <div className="panel p-3 grid md:grid-cols-[230px_1fr] gap-3 min-h-[420px]">
          <div className="flex flex-col items-center justify-center gap-4">
            <div className={`core ${listening || speaking || thinking ? "active" : ""}`}>
              <div className="ring" /><div className="ring r2" /><div className="ring r3" /><div className="heart" />
            </div>
            <div className={`bars flex items-end gap-1 h-6 ${speaking && !listening ? "on" : ""}`}>
              {[0, 1, 2, 3, 4].map((i) => <span key={i} style={listening ? { height: 4 + Math.min(1, voice.level * 10 * (0.6 + 0.1 * i)) * 20 } : undefined} />)}
            </div>
            <div className="flex gap-2">
              <button onClick={() => (listening && !voice.wake ? voice.stop() : voice.start())} className={`px-4 py-2 rounded-full border border-stark ${listening ? "bg-stark text-black" : "text-stark"}`}>
                {listening && !voice.wake ? "Parar" : "🎙 Falar"}
              </button>
              <button onClick={voice.toggleWake} className={`px-3 py-2 rounded-full border text-xs ${voice.wake ? "bg-silver text-black border-silver" : "border-silver text-silver"}`}>
                Palavra-chave {voice.wake ? "ON" : "OFF"}
              </button>
              {speaking && <button onClick={stopSpeech} className="px-3 py-2 rounded-full border border-silver text-silver">Interromper</button>}
            </div>
          </div>
          <div className="flex flex-col min-h-0 max-h-[60vh] overflow-y-auto gap-2 pr-1">
            {msgs.length === 0 && <p className="text-silver/60 text-sm m-auto">Diga “Jarvis, você está aí?” ou digite abaixo. (Requer backend rodando e ANTHROPIC_API_KEY no .env)</p>}
            {msgs.map((m, i) => (
              <div key={i} className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${m.role === "user" ? "self-end bg-stark/20 border border-stark/40" : "self-start border border-silver/30"}`}>
                {m.text}<div className="text-[10px] text-silver/50 mt-1">{m.ts}{m.voice ? " · voz" : ""}</div>
              </div>
            ))}
            <div ref={endRef} />
          </div>
        </div>

        <form className="panel p-2 flex gap-2" onSubmit={(e) => { e.preventDefault(); send(input); }}>
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Digite um comando, senhor…"
            className="flex-1 bg-transparent outline-none px-3 text-sm" />
          <button className="px-4 py-2 rounded-lg bg-stark text-black font-semibold">Enviar</button>
        </form>
      </section>

      <aside className="panel p-3 flex flex-col gap-3 min-h-[300px]">
        <nav className="flex flex-wrap gap-1 text-xs">
          {tabs.map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`flex-1 min-w-[70px] py-1 rounded border ${tab === k ? "border-stark text-stark" : "border-silver/30 text-silver"}`}>{l}</button>
          ))}
        </nav>
        <div className="text-sm overflow-y-auto">
          {tab === "tasks" && <MissionsPanel api={API} onError={notify} />}
          {tab === "tools" && <ToolsPanel api={API} onError={notify} />}
          {tab === "memory" && <MemoryPanel api={API} refreshKey={memTick} onError={notify} />}
          {tab === "voice" && (voiceHist.length ? (
            <>
              {voiceHist.map((n, i) => <p key={i} className="mb-1">{n}</p>)}
              <button onClick={() => setVoiceHist([])} className="mt-2 text-xs underline text-silver">Limpar histórico de voz</button>
            </>
          ) : <p className="text-silver/70">Nenhum comando de voz ainda.</p>)}
          {tab === "notes" && (notes.length ? notes.map((n, i) => <p key={i} className="mb-1">{n}</p>) : <p className="text-silver/70">Sem alertas.</p>)}
          {tab === "settings" && (
            <div className="grid gap-3">
              <label className="grid gap-1">Voz
                <select value={voiceURI} onChange={(e) => setVoiceURI(e.target.value)} className="bg-black border border-silver/30 rounded p-1">
                  <option value="">Padrão do sistema</option>
                  {voices.map((v) => <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>)}
                </select>
              </label>
              <label className="grid gap-1">Volume {Math.round(volume * 100)}%
                <input type="range" min={0} max={1} step={0.05} value={volume} onChange={(e) => setVolume(+e.target.value)} />
              </label>
              <label className="grid gap-1">Silêncio para encerrar a fala: {(silenceMs / 1000).toFixed(1)}s
                <input type="range" min={800} max={4000} step={100} value={silenceMs} onChange={(e) => setSilenceMs(+e.target.value)} />
              </label>
              <button onClick={() => speak("À disposição, senhor.")} className="py-1 rounded border border-stark text-stark">Testar voz</button>
            </div>
          )}
        </div>
      </aside>
    </main>
  );
}
