"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { authHeaders } from "./api";

type ToolInfo = { name: string; description: string; risk: string; enabled: boolean };
type Task = { id: number; title: string; due_at: string | null; done: boolean };
type Rem = { id: number; text: string; due_at: string };

export default function ToolsPanel({ api, onError }: { api: string; onError: (m: string) => void }) {
  const [tools, setTools] = useState<ToolInfo[]>([]);
  const [workspace, setWorkspace] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [rems, setRems] = useState<Rem[]>([]);
  const [title, setTitle] = useState(""); const [rText, setRText] = useState(""); const [rWhen, setRWhen] = useState("");
  const errRef = useRef(onError); errRef.current = onError;

  const call = useCallback(async (path: string, init?: RequestInit) => {
    const r = await fetch(api + path, { headers: { "Content-Type": "application/json", ...authHeaders() }, ...init });
    if (r.status === 401) { window.dispatchEvent(new Event("jarvis:unauthorized")); }
    if (!r.ok) throw new Error(String(r.status));
    return r.status === 204 ? null : r.json();
  }, [api]);

  const load = useCallback(async () => {
    try {
      const t = await call("/api/tools"); setTools(t.tools); setWorkspace(t.workspace);
      setTasks(await call("/api/tasks")); setRems(await call("/api/reminders"));
    } catch { errRef.current("Não foi possível carregar as ferramentas (backend offline?)."); }
  }, [call]);
  useEffect(() => { load(); const id = setInterval(load, 8000); return () => clearInterval(id); }, [load]);

  const act = async (fn: () => Promise<any>) => { try { await fn(); await load(); } catch { errRef.current("A operação falhou."); } };
  const btn = "px-2 py-0.5 rounded border border-silver/40 text-[11px] text-silver";
  const fmt = (d: string) => new Date(d).toLocaleString("pt-BR");

  return (
    <div className="grid gap-4 text-xs">
      <section className="grid gap-1">
        <b>Ferramentas (usadas pelas missões)</b>
        <p className="text-silver/60 break-all">Pasta de trabalho: {workspace}</p>
        {tools.map((t) => (
          <label key={t.name} className="flex gap-2 items-start" title={t.description}>
            <input type="checkbox" checked={t.enabled} disabled={t.risk !== "low"}
              onChange={() => act(() => call(`/api/tools/${t.name}`, { method: "PUT", body: JSON.stringify({ enabled: !t.enabled }) }))} />
            <span><code>{t.name}</code> <span className="text-silver/60">{t.description.slice(0, 70)}{t.risk !== "low" ? " (exige confirmação: bloqueada)" : ""}</span></span>
          </label>
        ))}
      </section>

      <section className="grid gap-1">
        <b>Tarefas</b>
        <form className="flex gap-1" onSubmit={(e) => { e.preventDefault(); if (!title.trim()) return;
          act(() => call("/api/tasks", { method: "POST", body: JSON.stringify({ title }) })); setTitle(""); }}>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Nova tarefa…" className="flex-1 bg-black border border-silver/30 rounded px-2 py-1" />
          <button className={btn}>+</button>
        </form>
        {tasks.length === 0 && <p className="text-silver/60">Sem tarefas.</p>}
        {tasks.map((t) => (
          <div key={t.id} className="flex gap-2 items-center">
            <input type="checkbox" checked={t.done} onChange={() => act(() => call(`/api/tasks/${t.id}`, { method: "PATCH", body: JSON.stringify({ done: !t.done }) }))} />
            <span className={t.done ? "line-through text-silver/50 flex-1" : "flex-1"}>{t.title}{t.due_at ? ` · ${fmt(t.due_at)}` : ""}</span>
            <button className={btn} onClick={() => act(() => call(`/api/tasks/${t.id}`, { method: "DELETE" }))}>✕</button>
          </div>
        ))}
      </section>

      <section className="grid gap-1">
        <b>Lembretes (avisam por voz com o app aberto)</b>
        <form className="grid gap-1" onSubmit={(e) => { e.preventDefault(); if (!rText.trim() || !rWhen) return;
          act(() => call("/api/reminders", { method: "POST", body: JSON.stringify({ text: rText, due_at: new Date(rWhen).toISOString() }) })); setRText(""); setRWhen(""); }}>
          <input value={rText} onChange={(e) => setRText(e.target.value)} placeholder="Lembrar de…" className="bg-black border border-silver/30 rounded px-2 py-1" />
          <span className="flex gap-1">
            <input type="datetime-local" value={rWhen} onChange={(e) => setRWhen(e.target.value)} className="flex-1 bg-black border border-silver/30 rounded px-2 py-1" />
            <button className={btn}>+</button>
          </span>
        </form>
        {rems.length === 0 && <p className="text-silver/60">Sem lembretes pendentes.</p>}
        {rems.map((r) => (
          <div key={r.id} className="flex gap-2 items-center">
            <span className="flex-1">{fmt(r.due_at)} · {r.text}</span>
            <button className={btn} onClick={() => act(() => call(`/api/reminders/${r.id}`, { method: "DELETE" }))}>✕</button>
          </div>
        ))}
      </section>
    </div>
  );
}
