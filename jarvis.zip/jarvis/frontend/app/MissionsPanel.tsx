"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { authHeaders } from "./api";

type Step = { title: string; description: string; web: boolean; status: string; attempts: number; tools?: string[] };
type Mission = { id: number; objective: string; status: string; steps: Step[]; result: string; error: string };

const ICON: Record<string, string> = { pending: "○", running: "◐", done: "●", failed: "✕" };
const LABEL: Record<string, string> = { pending: "na fila", planning: "planejando", running: "executando", completed: "concluída", failed: "falhou", cancelled: "cancelada" };
const ACTIVE = ["pending", "planning", "running"];

export default function MissionsPanel({ api, onError }: { api: string; onError: (m: string) => void }) {
  const [items, setItems] = useState<Mission[]>([]);
  const [objective, setObjective] = useState("");
  const [open, setOpen] = useState<number | null>(null);
  const errRef = useRef(onError); errRef.current = onError;

  const call = useCallback(async (path: string, init?: RequestInit) => {
    const r = await fetch(api + path, { headers: { "Content-Type": "application/json", ...authHeaders() }, ...init });
    if (r.status === 401) { window.dispatchEvent(new Event("jarvis:unauthorized")); }
    if (!r.ok) { let d = ""; try { d = (await r.json()).detail; } catch {} throw new Error(d || String(r.status)); }
    return r.json();
  }, [api]);

  const load = useCallback(async () => { try { setItems(await call("/api/missions")); } catch {} }, [call]);
  useEffect(() => { load(); const id = setInterval(load, 2500); return () => clearInterval(id); }, [load]);

  const act = async (fn: () => Promise<any>) => { try { await fn(); await load(); } catch (e: any) { errRef.current(e.message || "Falha na operação."); } };
  const btn = "px-2 py-0.5 rounded border border-silver/40 text-[11px] text-silver";
  const anyActive = items.some((m) => ACTIVE.includes(m.status));

  return (
    <div className="grid gap-3 text-xs">
      <form className="grid gap-1" onSubmit={(e) => { e.preventDefault(); if (objective.trim().length < 5) return;
        act(async () => { const m = await call("/api/missions", { method: "POST", body: JSON.stringify({ objective }) }); setOpen(m.id); }); setObjective(""); }}>
        <textarea value={objective} onChange={(e) => setObjective(e.target.value)} rows={3}
          placeholder="Descreva a missão. Ex.: pesquise oportunidades de negócios e prepare um relatório com as melhores opções."
          className="bg-black border border-silver/30 rounded p-2" />
        <button className="py-1 rounded bg-stark text-black font-semibold">Iniciar missão</button>
      </form>
      {anyActive && (
        <button className="py-1 rounded border border-stark text-stark font-bold" onClick={() => act(() => call("/api/missions/stop-all", { method: "POST" }))}>
          ⛔ PARAR TUDO
        </button>
      )}
      {items.length === 0 && <p className="text-silver/60">Nenhuma missão ainda.</p>}
      {items.map((m) => (
        <div key={m.id} className="border border-silver/30 rounded p-2 grid gap-1">
          <button className="text-left" onClick={() => setOpen(open === m.id ? null : m.id)}>
            <span className={ACTIVE.includes(m.status) ? "text-stark" : m.status === "completed" ? "text-green-400" : "text-silver"}>[{LABEL[m.status] ?? m.status}]</span>{" "}
            {m.objective.slice(0, 90)}
          </button>
          {open === m.id && (
            <div className="grid gap-2">
              {m.steps.length > 0 && (
                <ol className="grid gap-0.5">
                  {m.steps.map((s, i) => (
                    <li key={i}>{ICON[s.status] ?? "○"} {s.title}{s.web ? " 🌐" : ""}{s.tools && s.tools.length ? ` 🔧 ${s.tools.join(", ")}` : ""}{s.attempts > 1 ? ` (tentativa ${s.attempts})` : ""}</li>
                  ))}
                </ol>
              )}
              {m.error && <p className="text-stark whitespace-pre-wrap">{m.error}</p>}
              {m.result && <pre className="whitespace-pre-wrap max-h-72 overflow-y-auto border border-silver/20 rounded p-2 font-sans">{m.result}</pre>}
              {ACTIVE.includes(m.status) && <button className={btn} onClick={() => act(() => call(`/api/missions/${m.id}/cancel`, { method: "POST" }))}>Cancelar</button>}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
