"use client";
import { useEffect, useState } from "react";
import { authFetch, clearToken, getToken, setToken } from "./api";

type Status = "checking" | "locked" | "ready";

export default function LoginGate({ api, children }: { api: string; children: React.ReactNode }) {
  const [status, setStatus] = useState<Status>("checking");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const checkAuth = async () => {
    try {
      const r = await fetch(`${api}/api/auth/status`);
      const j = await r.json();
      if (!j.auth_required) {
        setStatus("ready");
        return;
      }
      if (!getToken()) {
        setStatus("locked");
        return;
      }
      // Valida o token existente contra uma rota protegida leve.
      const probe = await authFetch(api, "/api/memory/settings");
      setStatus(probe.ok ? "ready" : "locked");
    } catch {
      // Backend offline: deixa a UI própria mostrar "offline" em vez de travar no login.
      setStatus("ready");
    }
  };

  useEffect(() => {
    checkAuth();
    const onUnauth = () => setStatus("locked");
    window.addEventListener("jarvis:unauthorized", onUnauth);
    return () => window.removeEventListener("jarvis:unauthorized", onUnauth);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || busy) return;
    setErr("");
    setBusy(true);
    try {
      const r = await fetch(`${api}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (!r.ok) {
        setErr(r.status === 429 ? "Muitas tentativas. Aguarde alguns minutos." : "Senha incorreta.");
        return;
      }
      const j = await r.json();
      setToken(j.token);
      setPassword("");
      setStatus("ready");
    } catch {
      setErr("Não foi possível falar com o backend. Ele está rodando?");
    } finally {
      setBusy(false);
    }
  };

  if (status === "checking") {
    return <main className="min-h-screen grid place-items-center text-silver text-sm">Verificando acesso…</main>;
  }

  if (status === "locked") {
    return (
      <main className="min-h-screen grid place-items-center p-4">
        <form onSubmit={submit} className="panel p-6 grid gap-3 w-full max-w-sm">
          <span className="tracking-[.35em] text-stark font-bold text-center">J.A.R.V.I.S</span>
          <p className="text-xs text-silver/70 text-center">Acesso protegido. Digite a senha de administrador.</p>
          <input
            type="password"
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Senha"
            className="bg-black border border-silver/30 rounded px-3 py-2 text-sm"
          />
          {err && <p className="text-stark text-xs text-center">{err}</p>}
          <button disabled={busy} className="py-2 rounded bg-stark text-black font-semibold text-sm disabled:opacity-50">
            {busy ? "Entrando…" : "Entrar"}
          </button>
        </form>
      </main>
    );
  }

  return <>{children}</>;
}

export function logout() {
  clearToken();
  window.dispatchEvent(new Event("jarvis:unauthorized"));
}
