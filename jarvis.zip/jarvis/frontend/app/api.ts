"use client";
// Camada fina de autenticação para o frontend (Etapa 8).
// Guarda o token no localStorage do navegador e o anexa a toda chamada ao backend.

const TOKEN_KEY = "jarvis_token";

export function getToken(): string {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch {
    return "";
  }
}

export function setToken(t: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, t);
  } catch {}
}

export function clearToken(): void {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {}
}

export function authHeaders(): Record<string, string> {
  const t = getToken();
  return t ? { Authorization: `Bearer ${t}` } : {};
}

/** fetch com Content-Type + Authorization. Em 401, limpa o token e avisa a tela de login. */
export async function authFetch(api: string, path: string, init?: RequestInit): Promise<Response> {
  const r = await fetch(api + path, {
    ...init,
    headers: { "Content-Type": "application/json", ...authHeaders(), ...(init?.headers || {}) },
  });
  if (r.status === 401) {
    clearToken();
    window.dispatchEvent(new Event("jarvis:unauthorized"));
  }
  return r;
}

/** URL do WebSocket de chat, já com o token (se houver) na query string. */
export function wsUrl(api: string): string {
  const base = api.replace(/^http/, "ws") + "/ws/chat";
  const t = getToken();
  return t ? `${base}?token=${encodeURIComponent(t)}` : base;
}
