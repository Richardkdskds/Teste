import "./globals.css";
import SWRegister from "./SWRegister";

export const metadata = {
  title: "JARVIS",
  description: "Assistente pessoal de IA",
  manifest: "/manifest.json",
  icons: { icon: "/icon.svg", apple: "/icon.svg" },
};
export const viewport = { themeColor: "#000000" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        {children}
        <SWRegister />
      </body>
    </html>
  );
}
