"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { authHeaders } from "./api";

type Mem = { id: number; kind: string; category: string; content: string; status: string; expires_at: string | null };
type Cfg = { memory_enabled: boolean; auto_propose: boolean };

export default function MemoryPanel({ api, refreshKey, onError }: { api: string; refreshKey: number; onError: (m: string) => void }) {
  const [items, setItems] = useState<Mem[]>([]);
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [q, setQ] = useState(""); const [applied, setApplied] = useState("");
  const [draft, setDraft] = useState(""); const [kind, setKind] = useState("long");
  const [editing, setEditing] = useState<number | null>(null); const [editText, setEditText] = useState("");
  const errRef = useRef(onError); errRef.current = onError;

  const call = useCallback(async (path: string, init?: RequestInit) => {
    const r = await fetch(api + path, { headers: { "Content-Type": "application/json", ...authHeaders() }, ...init });
    if (r.status === 401) { window.dispatchEvent(new Event("jarvis:unauthorized")); }
    if (!r.ok) throw new Error(String(r.status));
    return r.status === 204 ? null : r.json();
  }, [api]);

  const load = useCallback(async () => {
    try {
      setItems(await call(applied ? `/api/memory/search?q=${encodeURIComponent(applied)}` : "/api/memory"));
      setCfg(await call("/api/memory/settings"));
    } catch { errRef.current("Não foi possível carregar a memória (backend offline?)."); }
  }, [call, applied]);
  useEffect(() => { load(); }, [load, refreshKey]);

  const act = async (fn: () => Promise<any>) => { try { await fn(); await load(); } catch { errRef.current("A operação de memória falhou."); } };
  const patch = (id: number, body: object) => act(() => call(`/api/memory/${id}`, { method: "PATCH", body: JSON.stringify(body) }));
  const toggle = (k: keyof Cfg) => cfg && act(() => call("/api/memory/settings", { method: "PUT", body: JSON.stringify({ [k]: !cfg[k] }) }));
  const btn = "px-2 py-0.5 rounded border border-silver/40 text-[11px] text-silver";

  const proposed = items.filter((m) => m.status === "proposed");
  const active = items.filter((m) => m.status === "active");

  return (
    <div className="grid gap-3 text-xs">
      {cfg && (
        <div className="grid gap-1">
          <label><input type="checkbox" checked={cfg.memory_enabled} onChange={() => toggle("memory_enabled")} /> Memória ligada (usada nas conversas)</label>
          <label><input type="checkbox" checked={cfg.auto_propose} onChange={() => toggle("auto_propose")} /> Sugerir memórias automaticamente (você aprova)</label>
        </div>
      )}
      <form className="flex gap-1" onSubmit={(e) => { e.preventDefault(); setApplied(q.trim()); }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar na memória…" className="flex-1 bg-black border border-silver/30 rounded px-2 py-1" />
        <button className={btn}>Buscar</button>
        {applied && <button type="button" className={btn} onClick={() => { setQ(""); setApplied(""); }}>Limpar</button>}
      </form>
      <form className="flex gap-1" onSubmit={(e) => { e.preventDefault(); if (!draft.trim()) return;
        act(() => call("/api/memory", { method: "POST", body: JSON.stringify({ content: draft, kind }) })); setDraft(""); }}>
        <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Adicionar memória…" className="flex-1 bg-black border border-silver/30 rounded px-2 py-1" />
        <select value={kind} onChange={(e) => setKind(e.target.value)} className="bg-black border border-silver/30 rounded">
          <option value="long">longo prazo</option><option value="short">curto (24h)</option>
        </select>
        <button className={btn}>+</button>
      </form>

      {proposed.length > 0 && (
        <div className="grid gap-1">
          <b className="text-stark">Sugeridas pelo Jarvis (aguardando você)</b>
          {proposed.map((m) => (
            <div key={m.id} className="border border-stark/40 rounded p-2 grid gap-1">
              <span>{m.content} <i className="text-silver/50">({m.kind === "short" ? "curto" : "longo"})</i></span>
              <span className="flex gap-1">
                <button className={btn} onClick={() => patch(m.id, { status: "active" })}>Aprovar</button>
                <button className={btn} onClick={() => act(() => call(`/api/memory/${m.id}`, { method: "DELETE" }))}>Rejeitar</button>
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="grid gap-1">
        <b>{applied ? `Resultados para “${applied}”` : "Memórias ativas"} ({active.length})</b>
        {active.length === 0 && <p className="text-silver/60">Nada aqui ainda.</p>}
        {active.map((m) => (
          <div key={m.id} className="border border-silver/30 rounded p-2 grid gap-1">
            {editing === m.id ? (
              <input value={editText} onChange={(e) => setEditText(e.target.value)} className="bg-black border border-silver/30 rounded px-1 py-0.5" />
            ) : (
              <span>{m.content} <i className="text-silver/50">({m.kind === "short" ? "curto" : "longo"}, {m.category})</i></span>
            )}
            <span className="flex gap-1">
              {editing === m.id ? (
                <>
                  <button className={btn} onClick={() => { patch(m.id, { content: editText }); setEditing(null); }}>Salvar</button>
                  <button className={btn} onClick={() => setEditing(null)}>Cancelar</button>
                </>
              ) : (
                <button className={btn} onClick={() => { setEditing(m.id); setEditText(m.content); }}>Editar</button>
              )}
              <button className={btn} onClick={() => act(() => call(`/api/memory/${m.id}`, { method: "DELETE" }))}>Excluir</button>
            </span>
          </div>
        ))}
      </div>
      <button className={`${btn} border-stark text-stark`} onClick={() => { if (confirm("Apagar TODA a memória? Isso não pode ser desfeito.")) act(() => call("/api/memory", { method: "DELETE" })); }}>
        Apagar toda a memória
      </button>
    </div>
  );
}
