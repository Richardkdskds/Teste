"use client";
import { useEffect } from "react";

/** Registra o service worker em produção (necessário no Android para "Adicionar à tela inicial"). */
export default function SWRegister() {
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;
    if (process.env.NODE_ENV !== "production") return; // evita cache preso durante `next dev`
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  return null;
}
