"use client";
import { useCallback, useEffect, useRef, useState } from "react";

type Opts = { onFinal: (text: string) => void; onError: (m: string) => void; speaking: boolean; silenceMs: number };

/** Voz no navegador: botão de falar (com detecção de silêncio), medidor real de áudio e modo palavra-chave "Jarvis"
 *  (só funciona com a página aberta; veja docs/VOZ.md). */
export function useVoice({ onFinal, onError, speaking, silenceMs }: Opts) {
  const [listening, setListening] = useState(false);
  const [wake, setWake] = useState(false);
  const [level, setLevel] = useState(0);
  const rec = useRef<any>(null);
  const running = useRef(false);
  const wakeRef = useRef(false);
  const speakingRef = useRef(speaking);
  const cb = useRef({ onFinal, onError, silenceMs });
  const runWakeRef = useRef<() => void>(() => {});
  const meter = useRef<{ stream?: MediaStream; ctx?: AudioContext; raf?: number }>({});
  cb.current = { onFinal, onError, silenceMs };
  speakingRef.current = speaking;

  const stopMeter = useCallback(() => {
    const m = meter.current;
    if (m.raf) cancelAnimationFrame(m.raf);
    m.stream?.getTracks().forEach((t) => t.stop());
    m.ctx?.close().catch(() => {});
    meter.current = {}; setLevel(0);
  }, []);

  const startMeter = useCallback(async (autoStop: boolean) => {
    if (meter.current.stream) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const ctx = new AudioContext(); const an = ctx.createAnalyser(); an.fftSize = 512;
      ctx.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      const startedAt = Date.now(); let lastVoice = 0;
      const tick = () => {
        an.getByteTimeDomainData(buf);
        let sum = 0; for (const v of buf) { const x = (v - 128) / 128; sum += x * x; }
        const rms = Math.sqrt(sum / buf.length); setLevel(rms);
        const t = Date.now();
        if (rms > 0.03) lastVoice = t;
        if (autoStop) {
          if (lastVoice && t - lastVoice > cb.current.silenceMs) rec.current?.stop();
          else if (!lastVoice && t - startedAt > 8000) rec.current?.stop();
        }
        meter.current.raf = requestAnimationFrame(tick);
      };
      meter.current = { stream, ctx, raf: requestAnimationFrame(tick) };
    } catch { cb.current.onError("Microfone indisponível ou permissão negada."); }
  }, []);

  const create = (continuous: boolean) => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { cb.current.onError("Reconhecimento de fala não suportado neste navegador. Use Chrome ou Edge."); return null; }
    const r = new SR(); r.lang = "pt-BR"; r.continuous = continuous; r.interimResults = false;
    r.onerror = (e: any) => {
      if (e.error !== "no-speech" && e.error !== "aborted") cb.current.onError(`Erro de voz: ${e.error}`);
      if (e.error === "not-allowed" || e.error === "service-not-allowed") { wakeRef.current = false; setWake(false); }
    };
    return r;
  };

  const start = useCallback(() => {
    if (wakeRef.current) return cb.current.onError("Desative o modo palavra-chave para usar o botão.");
    const r = create(false); if (!r) return;
    r.onresult = (e: any) => cb.current.onFinal(e.results[0][0].transcript);
    r.onend = () => { running.current = false; setListening(false); stopMeter(); };
    rec.current = r; running.current = true; r.start(); setListening(true); startMeter(true);
  }, [startMeter, stopMeter]);

  const stop = useCallback(() => rec.current?.stop(), []);

  runWakeRef.current = () => {
    if (!wakeRef.current || speakingRef.current || running.current) return;
    const r = create(true); if (!r) return;
    r.onresult = (e: any) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (!e.results[i].isFinal) continue;
        const text: string = e.results[i][0].transcript.trim();
        if (/jarvis/i.test(text)) cb.current.onFinal(text);
      }
    };
    r.onend = () => { running.current = false; setListening(false); if (wakeRef.current) setTimeout(() => runWakeRef.current(), 400); };
    rec.current = r;
    try { r.start(); running.current = true; setListening(true); } catch { running.current = false; }
  };

  const toggleWake = useCallback(() => {
    if (wakeRef.current) { wakeRef.current = false; setWake(false); rec.current?.stop(); stopMeter(); return; }
    rec.current?.stop();
    wakeRef.current = true; setWake(true); startMeter(false);
    setTimeout(() => runWakeRef.current(), 400);
  }, [startMeter, stopMeter]);

  // Pausa a escuta enquanto o Jarvis fala (evita que ele ouça a si mesmo) e retoma depois.
  useEffect(() => {
    if (!wakeRef.current) return;
    if (speaking) rec.current?.stop(); else { const t = setTimeout(() => runWakeRef.current(), 600); return () => clearTimeout(t); }
  }, [speaking]);

  useEffect(() => () => { wakeRef.current = false; rec.current?.stop(); stopMeter(); }, [stopMeter]);

  return { listening, wake, level, start, stop, toggleWake };
}
