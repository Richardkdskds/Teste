"""Plugin de exemplo: copie este arquivo, mude o nome e a função, reinicie o backend. Sem recompilar nada."""
from datetime import datetime

from app.tools.base import tool


@tool("current_time", "Devolve a data e hora atuais do servidor.", {"type": "object", "properties": {}, "required": []})
def current_time(args):
    return datetime.now().astimezone().isoformat(timespec="seconds")
