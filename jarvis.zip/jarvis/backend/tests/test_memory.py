from fastapi.testclient import TestClient

from app.core import llm
from app.main import app


class Fake:
    async def stream(self, system, messages):
        self.system = system
        yield "Entendido, senhor."

    async def complete(self, system, messages, max_tokens=300):
        return '[{"content":"Trabalha com logística","kind":"long","category":"info"}]'


def test_crud_search_settings():
    with TestClient(app) as c:
        c.delete("/api/memory")
        m = c.post("/api/memory", json={"content": "Prefiro respostas bem curtas", "category": "preference"}).json()
        assert [x["id"] for x in c.get("/api/memory").json()] == [m["id"]]
        assert c.get("/api/memory/search", params={"q": "quero respostas curtas"}).json()[0]["id"] == m["id"]
        assert c.patch(f"/api/memory/{m['id']}", json={"content": "Prefiro respostas longas"}).json()["content"].endswith("longas")
        s = c.post("/api/memory", json={"content": "Reunião amanhã", "kind": "short"}).json()
        assert s["expires_at"]
        assert c.put("/api/memory/settings", json={"memory_enabled": False}).json()["memory_enabled"] is False
        c.put("/api/memory/settings", json={"memory_enabled": True})
        assert c.delete(f"/api/memory/{m['id']}").status_code == 204
        assert c.delete(f"/api/memory/{m['id']}").status_code == 404
        assert c.delete("/api/memory").status_code == 204
        assert c.get("/api/memory").json() == []


def test_chat_proposes_then_uses_memory(monkeypatch):
    fake = Fake()
    monkeypatch.setattr(llm, "get_provider", lambda: fake)
    with TestClient(app) as c:
        c.delete("/api/memory")
        with c.websocket_connect("/ws/chat") as ws:
            ws.send_json({"text": "Eu trabalho com logística de cargas"})
            types = []
            while True:
                m = ws.receive_json(); types.append(m["type"])
                if m["type"] == "memory_proposed":
                    break
            assert "done" in types
        prop = c.get("/api/memory", params={"status": "proposed"}).json()
        assert len(prop) == 1
        # proposta ainda não é usada pelo Jarvis
        with c.websocket_connect("/ws/chat") as ws:
            ws.send_json({"text": "me fale sobre logística"})
            while ws.receive_json()["type"] != "done":
                pass
        assert "logística" not in fake.system
        c.patch(f"/api/memory/{prop[0]['id']}", json={"status": "active"})
        with c.websocket_connect("/ws/chat") as ws:
            ws.send_json({"text": "me fale sobre logística"})
            while ws.receive_json()["type"] != "done":
                pass
        assert "Trabalha com logística" in fake.system
