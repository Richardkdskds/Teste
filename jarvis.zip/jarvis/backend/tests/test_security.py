import time

from fastapi.testclient import TestClient

from app.core.config import settings
from app.main import app
from app.security import auth, rate_limit


def test_auth_disabled_by_default_allows_everything():
    """Sem JARVIS_ADMIN_PASSWORD (padrão dos testes/dev), nada fica bloqueado."""
    assert settings.jarvis_admin_password == ""
    with TestClient(app) as c:
        assert c.get("/api/auth/status").json() == {"auth_required": False}
        assert c.get("/api/memory").status_code == 200
        assert c.get("/api/tools").status_code == 200


def test_login_wrong_password_rejected(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", "senha-correta")
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-teste")
    rate_limit.reset("login:testclient")
    with TestClient(app) as c:
        r = c.post("/api/auth/login", json={"password": "errada"})
        assert r.status_code == 401


def test_login_right_password_grants_access_to_protected_route(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", "senha-correta")
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-teste")
    rate_limit.reset("login:testclient")
    with TestClient(app) as c:
        assert c.get("/api/auth/status").json() == {"auth_required": True}
        # sem token: bloqueado
        assert c.get("/api/memory").status_code == 401
        # login
        r = c.post("/api/auth/login", json={"password": "senha-correta"})
        assert r.status_code == 200
        token = r.json()["token"]
        # com token: liberado
        r2 = c.get("/api/memory", headers={"Authorization": f"Bearer {token}"})
        assert r2.status_code == 200


def test_expired_or_tampered_token_rejected(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", "senha-correta")
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-teste")
    expired_token, _ = auth.create_token(ttl_hours=-1)
    tampered = "9999999999." + "0" * 64
    with TestClient(app) as c:
        assert c.get("/api/memory", headers={"Authorization": f"Bearer {expired_token}"}).status_code == 401
        assert c.get("/api/memory", headers={"Authorization": f"Bearer {tampered}"}).status_code == 401
        assert c.get("/api/memory").status_code == 401  # sem cabeçalho


def test_login_rate_limited_after_many_attempts(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", "senha-correta")
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-teste")
    rate_limit.reset("login:testclient")
    with TestClient(app) as c:
        for _ in range(rate_limit.MAX_ATTEMPTS):
            c.post("/api/auth/login", json={"password": "errada"})
        r = c.post("/api/auth/login", json={"password": "errada"})
        assert r.status_code == 429


def test_chat_websocket_requires_token_when_auth_enabled(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", "senha-correta")
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-teste")
    with TestClient(app) as c:
        try:
            with c.websocket_connect("/ws/chat"):
                raised = False
        except Exception:
            raised = True
        assert raised, "a conexão sem token deveria ser recusada"

        token, _ = auth.create_token()
        with c.websocket_connect(f"/ws/chat?token={token}") as ws:
            ws.close()
