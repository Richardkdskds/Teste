from fastapi.testclient import TestClient

from app.core import llm
from app.main import app


class Fake:
    async def stream(self, system, messages):
        for t in ["À disposição, ", "senhor."]:
            yield t


def _collect(ws):
    got = []
    while True:
        m = ws.receive_json()
        if m["type"] == "delta":
            got.append(m["text"])
        else:
            return got, m


def test_chat_stream(monkeypatch):
    monkeypatch.setattr(llm, "get_provider", lambda: Fake())
    with TestClient(app) as c, c.websocket_connect("/ws/chat") as ws:
        ws.send_json({"text": "Jarvis, você está aí?"})
        got, last = _collect(ws)
        assert "".join(got) == "À disposição, senhor."
        assert last["type"] == "done"


def test_chat_without_key(monkeypatch):
    monkeypatch.setattr(llm.settings, "anthropic_api_key", "")
    with TestClient(app) as c, c.websocket_connect("/ws/chat") as ws:
        ws.send_json({"text": "olá"})
        _, last = _collect(ws)
        assert last["type"] == "error"
