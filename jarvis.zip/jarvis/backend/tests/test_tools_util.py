import pytest

from app.tools.util import ToolError, html_to_text, is_private_host, safe_path, slugify, unique_path


def test_safe_path(tmp_path):
    assert safe_path(tmp_path, "a/b.txt") == (tmp_path / "a" / "b.txt").resolve()
    for bad in ("../x", "/etc/passwd", "a/../../x"):
        with pytest.raises(ToolError):
            safe_path(tmp_path, bad)


def test_symlink_escape_blocked(tmp_path):
    outside = tmp_path.parent / "fora"; outside.mkdir(exist_ok=True)
    (tmp_path / "link").symlink_to(outside)
    with pytest.raises(ToolError):
        safe_path(tmp_path, "link/arquivo.txt")


def test_helpers(tmp_path):
    assert slugify("Relatório de Negócios 2026!") == "relatorio-de-negocios-2026"
    (tmp_path / "x.md").write_text("a")
    assert unique_path(tmp_path, "x", "md").name == "x-2.md"
    assert html_to_text("<html><script>evil()</script><p>Olá   <b>mundo</b></p></html>") == "Olá mundo"
    assert is_private_host("127.0.0.1") and is_private_host("localhost") and is_private_host("169.254.169.254")
