"""Teste de integração ponta a ponta (Etapa 10).

Percorre um fluxo realista do Jarvis inteiro, com a autenticação da Etapa 8
LIGADA (diferente dos outros arquivos de teste, que rodam com ela desligada):
login -> memória -> tarefas -> lembretes -> ferramentas -> missão (IA
simulada) -> chat (IA simulada) -> logout efetivo (token revogado ao trocar
a chave secreta). Cada módulo já tem testes unitários próprios nos outros
arquivos; este cobre a integração entre eles atrás da autenticação.
"""
import time

from fastapi.testclient import TestClient

from app.core.config import settings
from app.core import llm
from app.main import app
from app.security import rate_limit

PASSWORD = "senha-de-integracao"


class FakeAgent:
    """Simula o provedor de IA para missões e chat sem bater na Anthropic de verdade."""

    async def stream(self, system, messages):
        for t in ["Às suas ordens, ", "senhor."]:
            yield t

    async def run_tools(self, system, messages, tools, max_tokens, web_search, execute):
        return await self.complete(system, messages, max_tokens, web_search), []

    async def complete(self, system, messages, max_tokens=300, web_search=False):
        if "PLANEJADOR" in system:
            return '[{"title":"Levantar dados","description":"x"}]'
        if "EXECUTOR" in system:
            return "resultado do passo"
        if "VERIFICADOR" in system:
            return '{"ok": true, "issue": ""}'
        return "# Relatório final"


def _login(c: TestClient) -> str:
    rate_limit.reset("login:testclient")
    r = c.post("/api/auth/login", json={"password": PASSWORD})
    assert r.status_code == 200
    return r.json()["token"]


def _wait_mission(c, mid, token, want=("completed", "failed"), t=8):
    end = time.time() + t
    m = None
    while time.time() < end:
        m = c.get(f"/api/missions/{mid}", headers={"Authorization": f"Bearer {token}"}).json()
        if m["status"] in want:
            return m
        time.sleep(0.05)
    raise AssertionError(m)


def test_full_flow_with_auth_enabled(monkeypatch):
    monkeypatch.setattr(settings, "jarvis_admin_password", PASSWORD)
    monkeypatch.setattr(settings, "jarvis_secret_key", "chave-de-integracao")
    monkeypatch.setattr(llm, "get_provider", lambda: FakeAgent())
    monkeypatch.setattr(llm.settings, "anthropic_api_key", "x")

    with TestClient(app) as c:
        # 1. Sem token, tudo protegido fica fechado.
        assert c.get("/api/memory").status_code == 401

        # 2. Login.
        token = _login(c)
        auth = {"Authorization": f"Bearer {token}"}

        # 3. Memória: criar e buscar.
        mem = c.post("/api/memory", json={"content": "prefere café sem açúcar"}, headers=auth).json()
        assert "café" in c.get("/api/memory/search?q=café", headers=auth).json()[0]["content"]

        # 4. Tarefas e lembretes.
        task = c.post("/api/tasks", json={"title": "Revisar relatório"}, headers=auth).json()
        assert c.patch(f"/api/tasks/{task['id']}", json={"done": True}, headers=auth).json()["done"] is True

        # 5. Ferramentas: a lista exige token e reflete o que está habilitado.
        tools = c.get("/api/tools", headers=auth).json()["tools"]
        assert any(t["name"] == "add_task" for t in tools)

        # 6. Missão completa de ponta a ponta (IA simulada).
        mid = c.post("/api/missions", json={"objective": "Pesquise fornecedores de café"}, headers=auth).json()["id"]
        m = _wait_mission(c, mid, token)
        assert m["status"] == "completed" and m["result"] == "# Relatório final"

        # 7. Chat por WebSocket exige o token na query string.
        with c.websocket_connect(f"/ws/chat?token={token}") as ws:
            ws.send_json({"text": "Jarvis, você está aí?"})
            parts = []
            while True:
                msg = ws.receive_json()
                if msg["type"] == "delta":
                    parts.append(msg["text"])
                else:
                    assert msg["type"] == "done"
                    break
            assert "".join(parts) == "Às suas ordens, senhor."

        # 8. Trocar a chave secreta revoga todos os tokens emitidos (logout global).
        monkeypatch.setattr(settings, "jarvis_secret_key", "outra-chave-depois-da-troca")
        assert c.get("/api/memory", headers=auth).status_code == 401

        # limpeza
        c.delete(f"/api/memory/{mem['id']}", headers={"Authorization": f"Bearer {_login(c)}"})
