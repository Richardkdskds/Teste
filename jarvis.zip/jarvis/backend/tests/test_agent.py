import asyncio
import time

from fastapi.testclient import TestClient

from app.agent.parsing import parse_plan, parse_verdict
from app.core import llm
from app.main import app


def test_parse_plan_and_verdict():
    raw = 'Plano:\n[{"title":"Pesquisar","description":"d","web":true},{"title":""},{"title":"Resumir"}]'
    steps = parse_plan(raw, 8)
    assert [s["title"] for s in steps] == ["Pesquisar", "Resumir"] and steps[0]["web"] is True
    assert len(parse_plan(raw, 1)) == 1 and parse_plan("lixo", 8) == []
    assert parse_verdict('{"ok": false, "issue": "faltam fontes"}') == (False, "faltam fontes")
    assert parse_verdict("ilegível") == (True, "")


class Fake:
    def __init__(self, verdicts=None, slow=False):
        self.verdicts = list(verdicts or [True]); self.slow = slow; self.exec_calls = 0

    async def run_tools(self, system, messages, tools, max_tokens, web_search, execute):
        return await self.complete(system, messages, max_tokens, web_search), []

    async def complete(self, system, messages, max_tokens=300, web_search=False):
        if "PLANEJADOR" in system:
            return '[{"title":"Levantar dados","description":"x","web":true},{"title":"Consolidar","description":"y"}]'
        if "EXECUTOR" in system:
            self.exec_calls += 1
            if self.slow:
                await asyncio.sleep(5)
            return "resultado do passo"
        if "VERIFICADOR" in system:
            return '{"ok": %s, "issue": "faltam fontes"}' % str(self.verdicts.pop(0) if self.verdicts else True).lower()
        return "# Relatório final"


def _wait(c, mid, want, t=8):
    end = time.time() + t
    while time.time() < end:
        m = c.get(f"/api/missions/{mid}").json()
        if m["status"] in want:
            return m
        time.sleep(0.05)
    raise AssertionError(m["status"])


def test_mission_completes_with_retry(monkeypatch):
    fake = Fake(verdicts=[False, True, True])
    monkeypatch.setattr(llm, "get_provider", lambda: fake)
    monkeypatch.setattr(llm.settings, "anthropic_api_key", "x")
    with TestClient(app) as c:
        mid = c.post("/api/missions", json={"objective": "Pesquise fornecedores de café"}).json()["id"]
        m = _wait(c, mid, {"completed", "failed"})
        assert m["status"] == "completed" and m["result"] == "# Relatório final"
        assert [s["status"] for s in m["steps"]] == ["done", "done"] and m["steps"][0]["attempts"] == 2


def test_mission_can_be_cancelled(monkeypatch):
    monkeypatch.setattr(llm, "get_provider", lambda: Fake(slow=True))
    monkeypatch.setattr(llm.settings, "anthropic_api_key", "x")
    with TestClient(app) as c:
        mid = c.post("/api/missions", json={"objective": "Missão demorada de teste"}).json()["id"]
        time.sleep(0.3)
        assert c.post("/api/missions/stop-all").json()["cancelled"] == 1
        assert _wait(c, mid, {"cancelled"})["status"] == "cancelled"


def test_mission_requires_key(monkeypatch):
    monkeypatch.setattr(llm.settings, "anthropic_api_key", "")
    with TestClient(app) as c:
        assert c.post("/api/missions", json={"objective": "qualquer missão aqui"}).status_code == 400
