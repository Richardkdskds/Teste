from app.memory.search import parse_candidates, rank


def test_rank_finds_relevant_ignoring_accents():
    docs = [(1, "Prefiro respostas bem curtas"), (2, "Meu projeto é um app de receitas"), (3, "Gosto de café")]
    assert rank("Quero respostas curtas", docs)[0][0] == 1
    assert rank("projeto de aplicativo receitas", docs)[0][0] == 2
    assert rank("futebol", docs) == []


def test_parse_candidates_tolerant():
    raw = 'Claro:\n```json\n[{"content":"Mora em Recife","kind":"long","category":"info"},{"content":"x"},5]\n```'
    out = parse_candidates(raw)
    assert out == [{"content": "Mora em Recife", "kind": "long", "category": "info"}]
    assert parse_candidates("nada") == []
