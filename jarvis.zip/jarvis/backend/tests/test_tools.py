import asyncio
from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from app.core import llm
from app.main import app
from app.tools import base


def run(name, args):
    return asyncio.run(base.execute(name, args))


def test_files_are_sandboxed_and_never_overwrite():
    with TestClient(app):
        assert run("write_file", {"path": "notas/a.txt", "content": "olá"}).startswith("Arquivo criado")
        assert run("read_file", {"path": "notas/a.txt"}) == "olá"
        assert "já existe" in run("write_file", {"path": "notas/a.txt", "content": "x"}).lower()
        assert "fora da pasta" in run("read_file", {"path": "../segredo"}).lower()
        assert run("move_file", {"src": "notas/a.txt", "dst": "arquivo/b.txt"}).startswith("Movido")
        assert run("create_document", {"title": "Plano", "content": "- item", "format": "md"}).startswith("Documento criado")


def test_tasks_reminders_and_plugin():
    with TestClient(app):
        assert "criada" in run("add_task", {"title": "Ligar para fornecedor"})
        assert "Ligar para fornecedor" in run("list_tasks", {})
        soon = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        assert "criado" in run("create_reminder", {"text": "Reunião", "due_at": soon})
        assert "passou" in run("create_reminder", {"text": "x", "due_at": "2020-01-01T10:00:00+00:00"})
        assert run("current_time", {})  # plugin de exemplo carregado


def test_toggle_blocks_tool_and_fetch_needs_allowlist():
    with TestClient(app) as c:
        assert "não está disponível" in (c.put("/api/tools/list_files", json={"enabled": False}) and run("list_files", {}))
        c.put("/api/tools/list_files", json={"enabled": True})
        assert "desligada" in run("fetch_page", {"url": "https://example.com"})
        assert any(t["name"] == "create_reminder" for t in c.get("/api/tools").json()["tools"])
