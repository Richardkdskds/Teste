"""Leitura tolerante das respostas JSON do modelo (planejador e verificador)."""
import json


def _block(raw: str, o: str, c: str):
    a, b = raw.find(o), raw.rfind(c)
    if a < 0 or b < a:
        return None
    try:
        return json.loads(raw[a : b + 1])
    except ValueError:
        return None


def parse_plan(raw: str, max_steps: int) -> list[dict]:
    data = _block(raw, "[", "]")
    steps = []
    for it in data if isinstance(data, list) else []:
        if not isinstance(it, dict) or not isinstance(it.get("title"), str) or not it["title"].strip():
            continue
        steps.append({"title": it["title"].strip()[:120], "description": str(it.get("description", "")).strip()[:500],
                      "web": bool(it.get("web", False)), "status": "pending", "result": "", "attempts": 0, "tools": []})
    return steps[:max_steps]


def parse_verdict(raw: str) -> tuple[bool, str]:
    """(ok, problema). Se a resposta for ilegível, não trava a missão: considera ok."""
    d = _block(raw, "{", "}")
    if not isinstance(d, dict) or "ok" not in d:
        return True, ""
    return bool(d["ok"]), str(d.get("issue", ""))[:300]
