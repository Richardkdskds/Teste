"""Limitador de tentativas em memória (por processo), usado no login.

Não protege contra ataques distribuídos de várias origens — é apenas uma rede
de segurança básica contra força bruta de um único cliente. Se for expor o
Jarvis na internet, coloque também um proxy/firewall na frente dele.
"""
import time
from collections import defaultdict

WINDOW_SECONDS = 300
MAX_ATTEMPTS = 8

_attempts: dict[str, list[float]] = defaultdict(list)


def allow(key: str) -> bool:
    """Registra uma tentativa e diz se ela ainda é permitida dentro da janela."""
    now = time.time()
    hits = [t for t in _attempts[key] if now - t < WINDOW_SECONDS]
    hits.append(now)
    _attempts[key] = hits
    return len(hits) <= MAX_ATTEMPTS


def reset(key: str) -> None:
    _attempts.pop(key, None)
