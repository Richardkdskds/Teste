"""Autenticação simples por senha de administrador (Etapa 8).

Não há banco de usuários: existe um único operador (quem roda o Jarvis).
Se JARVIS_ADMIN_PASSWORD estiver vazio, a autenticação fica DESLIGADA (modo
de desenvolvimento) e nada aqui bloqueia requisições — exatamente como nas
etapas anteriores. Defina a senha em `.env` para proteger a API antes de
expor o backend fora do seu próprio computador.

O token é um HMAC-SHA256 assinado com JARVIS_SECRET_KEY, sem dependências
externas (sem biblioteca de JWT): `"<expira_em>.<assinatura>"`. Isso evita
adicionar pacotes novos ao projeto (o ambiente de desenvolvimento documentado
no README não tem internet para `pip install`).
"""
import hashlib
import hmac
import logging
import time

from fastapi import Header, HTTPException, WebSocket, status

from app.core.config import settings

log = logging.getLogger("jarvis.security")
_warned = False


def auth_enabled() -> bool:
    return bool(settings.jarvis_admin_password)


def _warn_once() -> None:
    global _warned
    if not _warned:
        log.warning(
            "JARVIS_ADMIN_PASSWORD não definido: autenticação DESLIGADA (modo dev). "
            "Defina-o em backend/.env antes de expor o Jarvis fora do seu computador."
        )
        _warned = True


def check_password(password: str) -> bool:
    """Compara em tempo constante para não vazar a senha por timing."""
    if not auth_enabled():
        return False
    return hmac.compare_digest(password.encode(), settings.jarvis_admin_password.encode())


def _secret() -> bytes:
    key = settings.jarvis_secret_key or settings.jarvis_admin_password or "jarvis-dev-insecure-key"
    return key.encode()


def create_token(ttl_hours: float | None = None) -> tuple[str, int]:
    """Gera um token assinado com expiração. Retorna (token, timestamp_de_expiracao)."""
    ttl = ttl_hours if ttl_hours is not None else settings.jarvis_token_ttl_hours
    exp = int(time.time() + ttl * 3600)
    payload = str(exp)
    sig = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}", exp


def verify_token(token: str | None) -> bool:
    if not token or "." not in token:
        return False
    payload, _, sig = token.partition(".")
    expected = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expected):
        return False
    try:
        return int(payload) >= int(time.time())
    except ValueError:
        return False


def require_auth(authorization: str | None = Header(None)) -> None:
    """Dependência FastAPI para rotas HTTP: exige `Authorization: Bearer <token>`
    quando a autenticação está ligada. Use com `dependencies=[Depends(require_auth)]`."""
    if not auth_enabled():
        _warn_once()
        return
    token = ""
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    if not verify_token(token):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Não autenticado. Faça login em /api/auth/login.")


async def ws_require_auth(ws: WebSocket) -> bool:
    """Para o WebSocket de chat: lê o token da query string (?token=...), já que
    um WebSocket não permite enviar cabeçalhos customizados a partir do navegador."""
    if not auth_enabled():
        _warn_once()
        return True
    return verify_token(ws.query_params.get("token"))
