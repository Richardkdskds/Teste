from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from app.security import auth, rate_limit

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginIn(BaseModel):
    password: str = Field(min_length=1, max_length=200)


@router.get("/status")
def status_():
    """O frontend chama isto antes de tudo para decidir se mostra a tela de login."""
    return {"auth_required": auth.auth_enabled()}


@router.post("/login")
def login(body: LoginIn, request: Request):
    ip = request.client.host if request.client else "desconhecido"
    if not rate_limit.allow(f"login:{ip}"):
        raise HTTPException(429, "Muitas tentativas de login. Aguarde alguns minutos.")
    if not auth.auth_enabled():
        # Autenticação desligada (sem JARVIS_ADMIN_PASSWORD): devolve um token válido
        # mesmo assim, para o frontend seguir o mesmo fluxo em dev e produção.
        token, exp = auth.create_token()
        return {"token": token, "expires_at": exp}
    if not auth.check_password(body.password):
        raise HTTPException(401, "Senha incorreta.")
    rate_limit.reset(f"login:{ip}")
    token, exp = auth.create_token()
    return {"token": token, "expires_at": exp}
