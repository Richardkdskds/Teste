import json
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.agent.persona import SYSTEM_PROMPT
from app.core import llm
from app.core.config import settings
from app.db.models import SessionLocal
from app.memory import service
from app.security.auth import ws_require_auth

log = logging.getLogger("jarvis.chat")
router = APIRouter()
MAX_HISTORY = 20


async def _maybe_propose(ws: WebSocket, provider, text: str) -> None:
    """Sugere memórias a partir da fala do usuário. Ficam 'proposed' até ele aprovar no painel."""
    if len(text) < 15:
        return
    try:
        with SessionLocal() as db:
            cfg = service.get_settings(db)
            if not (cfg["memory_enabled"] and cfg["auto_propose"]):
                return
            n = await service.propose(provider, db, text)
        if n:
            await ws.send_json({"type": "memory_proposed", "count": n})
    except Exception:
        log.exception("Falha ao propor memórias")


@router.websocket("/ws/chat")
async def chat(ws: WebSocket):
    origin = ws.headers.get("origin")
    allowed = [o.strip() for o in settings.jarvis_allowed_origins.split(",")]
    if origin and origin not in allowed:
        await ws.close(code=1008)
        return
    if not await ws_require_auth(ws):
        await ws.close(code=1008)
        return
    await ws.accept()
    history: list[dict] = []
    try:
        while True:
            try:
                text = str(json.loads(await ws.receive_text()).get("text", "")).strip()
            except ValueError:
                continue
            if not text:
                continue
            history.append({"role": "user", "content": text})
            history = history[-MAX_HISTORY:]
            while history and history[0]["role"] != "user":
                history.pop(0)
            try:
                provider = llm.get_provider()
                with SessionLocal() as db:
                    system = SYSTEM_PROMPT + service.memory_block(service.retrieve(db, text))
                parts: list[str] = []
                async for delta in provider.stream(system, history):
                    parts.append(delta)
                    await ws.send_json({"type": "delta", "text": delta})
                history.append({"role": "assistant", "content": "".join(parts)})
                await ws.send_json({"type": "done"})
            except llm.LLMNotConfigured as e:
                history.pop()
                await ws.send_json({"type": "error", "message": str(e)})
            except Exception:
                log.exception("Falha ao consultar a IA")
                history.pop()
                await ws.send_json({"type": "error", "message": "Falha ao falar com a IA. Verifique a chave e a conexão."})
            else:
                await _maybe_propose(ws, provider, text)
    except WebSocketDisconnect:
        pass
