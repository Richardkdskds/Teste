from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models import Reminder, Task, get_db
from app.security.auth import require_auth

router = APIRouter(prefix="/api", tags=["productivity"], dependencies=[Depends(require_auth)])


def _utc(d: datetime | None):
    if d is None:
        return None
    return (d.replace(tzinfo=timezone.utc) if d.tzinfo is None else d).isoformat()


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    due_at: datetime | None = None


class TaskPatch(BaseModel):
    done: bool


class ReminderIn(BaseModel):
    text: str = Field(min_length=1, max_length=300)
    due_at: datetime


def ser_task(t: Task):
    return {"id": t.id, "title": t.title, "due_at": _utc(t.due_at), "done": t.done}


def ser_rem(r: Reminder):
    return {"id": r.id, "text": r.text, "due_at": _utc(r.due_at), "delivered": r.delivered}


@router.get("/tasks")
def tasks(db: Session = Depends(get_db)):
    return [ser_task(t) for t in db.scalars(select(Task).order_by(Task.done, Task.id.desc()).limit(100))]


@router.post("/tasks")
def add_task(b: TaskIn, db: Session = Depends(get_db)):
    t = Task(title=b.title.strip(), due_at=b.due_at); db.add(t); db.commit()
    return ser_task(t)


@router.patch("/tasks/{tid}")
def patch_task(tid: int, b: TaskPatch, db: Session = Depends(get_db)):
    t = db.get(Task, tid)
    if not t:
        raise HTTPException(404, "Tarefa não encontrada")
    t.done = b.done; db.commit()
    return ser_task(t)


@router.delete("/tasks/{tid}", status_code=204)
def del_task(tid: int, db: Session = Depends(get_db)):
    t = db.get(Task, tid)
    if not t:
        raise HTTPException(404, "Tarefa não encontrada")
    db.delete(t); db.commit()
    return Response(status_code=204)


@router.get("/reminders")
def reminders(db: Session = Depends(get_db)):
    return [ser_rem(r) for r in db.scalars(select(Reminder).where(Reminder.delivered.is_(False)).order_by(Reminder.due_at))]


@router.post("/reminders")
def add_reminder(b: ReminderIn, db: Session = Depends(get_db)):
    due = b.due_at if b.due_at.tzinfo else b.due_at.astimezone()
    r = Reminder(text=b.text.strip(), due_at=due.astimezone(timezone.utc)); db.add(r); db.commit()
    return ser_rem(r)


@router.get("/reminders/due")
def due(db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    return [ser_rem(r) for r in db.scalars(select(Reminder).where(Reminder.delivered.is_(False), Reminder.due_at <= now))]


@router.post("/reminders/{rid}/ack")
def ack(rid: int, db: Session = Depends(get_db)):
    r = db.get(Reminder, rid)
    if not r:
        raise HTTPException(404, "Lembrete não encontrado")
    r.delivered = True; db.commit()
    return ser_rem(r)


@router.delete("/reminders/{rid}", status_code=204)
def del_reminder(rid: int, db: Session = Depends(get_db)):
    r = db.get(Reminder, rid)
    if not r:
        raise HTTPException(404, "Lembrete não encontrado")
    db.delete(r); db.commit()
    return Response(status_code=204)
