import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.agent import runner
from app.core.config import settings
from app.db.models import Mission, get_db
from app.security.auth import require_auth

router = APIRouter(prefix="/api/missions", tags=["missions"], dependencies=[Depends(require_auth)])


class MissionIn(BaseModel):
    objective: str = Field(min_length=5, max_length=2000)


def ser(m: Mission) -> dict:
    return {"id": m.id, "objective": m.objective, "status": m.status, "steps": json.loads(m.plan_json or "[]"),
            "result": m.result, "error": m.error, "created_at": m.created_at.isoformat(), "updated_at": m.updated_at.isoformat()}


@router.post("")
async def create(body: MissionIn, db: Session = Depends(get_db)):
    if not settings.anthropic_api_key:
        raise HTTPException(400, "A chave ANTHROPIC_API_KEY não está configurada no backend.")
    if len(runner.running) >= settings.jarvis_max_concurrent_missions:
        raise HTTPException(429, f"Já há {len(runner.running)} missões em execução. Aguarde ou cancele uma.")
    m = Mission(objective=body.objective.strip())
    db.add(m); db.commit()
    runner.start(m.id)
    return ser(m)


@router.get("")
def list_all(db: Session = Depends(get_db)):
    return [ser(m) for m in db.scalars(select(Mission).order_by(Mission.id.desc()).limit(30))]


@router.post("/stop-all")
def stop_all(db: Session = Depends(get_db)):
    """Botão de emergência: cancela todas as missões em andamento."""
    n = sum(runner.cancel(mid) for mid in list(runner.running))
    return {"cancelled": n}


@router.get("/{mid}")
def get_one(mid: int, db: Session = Depends(get_db)):
    m = db.get(Mission, mid)
    if not m:
        raise HTTPException(404, "Missão não encontrada")
    return ser(m)


@router.post("/{mid}/cancel")
def cancel(mid: int, db: Session = Depends(get_db)):
    m = db.get(Mission, mid)
    if not m:
        raise HTTPException(404, "Missão não encontrada")
    if not runner.cancel(mid) and m.status in ("pending", "planning", "running"):
        m.status = "cancelled"; db.commit()
    return ser(m)
