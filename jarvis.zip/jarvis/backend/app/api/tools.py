from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.security.auth import require_auth
from app.tools import base, builtin

router = APIRouter(prefix="/api/tools", tags=["tools"], dependencies=[Depends(require_auth)])


class Toggle(BaseModel):
    enabled: bool


@router.get("")
def list_tools():
    return {"workspace": str(builtin.root()),
            "tools": [{"name": t.name, "description": t.description, "risk": t.risk, "enabled": base.is_enabled(t.name)}
                      for t in base.REGISTRY.values()]}


@router.put("/{name}")
def toggle(name: str, body: Toggle):
    if name not in base.REGISTRY:
        raise HTTPException(404, "Ferramenta não encontrada")
    base.set_enabled(name, body.enabled)
    return {"name": name, "enabled": base.is_enabled(name)}
