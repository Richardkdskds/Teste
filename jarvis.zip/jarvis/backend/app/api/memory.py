from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.db.models import Memory, get_db
from app.memory import service
from app.security.auth import require_auth

router = APIRouter(prefix="/api/memory", tags=["memory"], dependencies=[Depends(require_auth)])
KIND = "^(short|long)$"
CAT = "^(preference|info|project|task|decision|context)$"


class MemoryIn(BaseModel):
    content: str = Field(min_length=1, max_length=1000)
    kind: str = Field("long", pattern=KIND)
    category: str = Field("info", pattern=CAT)


class MemoryPatch(BaseModel):
    content: str | None = Field(None, min_length=1, max_length=1000)
    kind: str | None = Field(None, pattern=KIND)
    category: str | None = Field(None, pattern=CAT)
    status: str | None = Field(None, pattern="^(active|proposed)$")


class SettingsIn(BaseModel):
    memory_enabled: bool | None = None
    auto_propose: bool | None = None


def ser(m: Memory) -> dict:
    return {"id": m.id, "kind": m.kind, "category": m.category, "content": m.content, "status": m.status,
            "expires_at": m.expires_at.isoformat() if m.expires_at else None}


@router.get("")
def list_all(status: str | None = Query(None, pattern="^(active|proposed)$"), db: Session = Depends(get_db)):
    return [ser(m) for m in service.list_memories(db, status)]


@router.post("")
def create(body: MemoryIn, db: Session = Depends(get_db)):
    return ser(service.create(db, body.content, body.kind, body.category))


@router.delete("", status_code=204)
def wipe(db: Session = Depends(get_db)):
    service.delete_all(db)
    return Response(status_code=204)


@router.get("/settings")
def get_settings(db: Session = Depends(get_db)):
    return service.get_settings(db)


@router.put("/settings")
def put_settings(body: SettingsIn, db: Session = Depends(get_db)):
    return service.set_settings(db, **body.model_dump())


@router.get("/search")
def search(q: str = Query(min_length=1), db: Session = Depends(get_db)):
    return [ser(m) for m in service.search(db, q, k=10)]


@router.patch("/{mid}")
def patch(mid: int, body: MemoryPatch, db: Session = Depends(get_db)):
    m = db.get(Memory, mid)
    if not m:
        raise HTTPException(404, "Memória não encontrada")
    return ser(service.update(db, m, **body.model_dump()))


@router.delete("/{mid}", status_code=204)
def remove(mid: int, db: Session = Depends(get_db)):
    m = db.get(Memory, mid)
    if not m:
        raise HTTPException(404, "Memória não encontrada")
    db.delete(m); db.commit()
    return Response(status_code=204)
