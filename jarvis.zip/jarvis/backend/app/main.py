from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.auth import router as auth_router
from app.api.chat import router as chat_router
from app.agent.runner import recover_orphans
from app.api.memory import router as memory_router
from app.api.missions import router as missions_router
from app.api.productivity import router as productivity_router
from app.api.tools import router as tools_router
from app.tools import base as tools_base
from pathlib import Path
from app.core.config import settings
from app.db.models import init_db

app = FastAPI(title="JARVIS")
app.include_router(auth_router)
app.include_router(chat_router)
app.include_router(memory_router)
app.include_router(missions_router)
app.include_router(tools_router)
app.include_router(productivity_router)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.jarvis_allowed_origins.split(",")],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup():
    init_db()
    recover_orphans()
    tools_base.load_plugins(Path(__file__).resolve().parents[1] / "plugins")


@app.middleware("http")
async def _security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


@app.get("/health")
def health():
    from app.security.auth import auth_enabled

    return {
        "status": "ok",
        "ai_configured": bool(settings.anthropic_api_key),
        "database": settings.database_url.split(":", 1)[0],
        "auth_required": auth_enabled(),
    }
