"""Configuração central. Chaves só existem no backend (variáveis de ambiente)."""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"
    database_url: str = "sqlite:///./jarvis.db"
    jarvis_admin_password: str = ""
    jarvis_secret_key: str = ""
    jarvis_token_ttl_hours: float = 12.0
    jarvis_allowed_origins: str = "http://localhost:3000"
    jarvis_max_steps_per_mission: int = 8
    jarvis_max_model_calls_per_mission: int = 40
    jarvis_max_concurrent_missions: int = 2
    jarvis_workspace: str = "./workspace"
    jarvis_allowed_domains: str = ""


settings = Settings()
