"""Camada de modelos. Hoje: Claude. Para adicionar outro modelo, crie um provider com o mesmo método `stream`."""
from typing import AsyncIterator, Protocol

from app.core.config import settings


class LLMNotConfigured(Exception):
    pass


class LLMProvider(Protocol):
    def stream(self, system: str, messages: list[dict]) -> AsyncIterator[str]: ...

    async def complete(self, system: str, messages: list[dict], max_tokens: int = 300, web_search: bool = False) -> str: ...


class ClaudeProvider:
    def __init__(self) -> None:
        if not settings.anthropic_api_key:
            raise LLMNotConfigured("A chave ANTHROPIC_API_KEY não está configurada no backend (.env).")
        from anthropic import AsyncAnthropic

        self.client = AsyncAnthropic(api_key=settings.anthropic_api_key)

    async def stream(self, system: str, messages: list[dict]) -> AsyncIterator[str]:
        async with self.client.messages.stream(
            model=settings.anthropic_model, max_tokens=1024, system=system, messages=messages
        ) as s:
            async for text in s.text_stream:
                yield text

    async def complete(self, system: str, messages: list[dict], max_tokens: int = 300, web_search: bool = False) -> str:
        """Resposta completa. Com web_search=True usa a ferramenta de busca nativa da Claude (precisa estar
        habilitada na sua organização no Console da Anthropic)."""
        kw = {"tools": [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]} if web_search else {}
        msgs, text = list(messages), []
        for _ in range(4):  # continua se a busca pausar o turno
            r = await self.client.messages.create(
                model=settings.anthropic_model, max_tokens=max_tokens, system=system, messages=msgs, **kw)
            text += [b.text for b in r.content if getattr(b, "type", "") == "text"]
            if r.stop_reason != "pause_turn":
                break
            msgs = msgs + [{"role": "assistant", "content": r.content}]
        return "".join(text)

    async def run_tools(self, system, messages, tools, max_tokens, web_search, execute):
        """Laço de uso de ferramentas: o modelo pede, `execute(nome, args)` roda, o resultado volta. Devolve (texto, usadas)."""
        specs = [{"name": t.name, "description": t.description, "input_schema": t.input_schema} for t in tools]
        if web_search:
            specs.append({"type": "web_search_20250305", "name": "web_search", "max_uses": 3})
        kw = {"tools": specs} if specs else {}
        msgs, text, used = list(messages), [], []
        for _ in range(8):
            r = await self.client.messages.create(
                model=settings.anthropic_model, max_tokens=max_tokens, system=system, messages=msgs, **kw)
            text += [b.text for b in r.content if getattr(b, "type", "") == "text"]
            if r.stop_reason == "tool_use":
                results = []
                for b in r.content:
                    if getattr(b, "type", "") == "tool_use":
                        used.append(b.name)
                        results.append({"type": "tool_result", "tool_use_id": b.id, "content": await execute(b.name, b.input)})
                msgs += [{"role": "assistant", "content": r.content}, {"role": "user", "content": results}]
                text = []
            elif r.stop_reason == "pause_turn":
                msgs.append({"role": "assistant", "content": r.content})
            else:
                break
        return ("".join(text) or "(limite de uso de ferramentas atingido sem resposta final)"), used


def get_provider() -> LLMProvider:
    return ClaudeProvider()
