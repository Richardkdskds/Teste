"""Registro de ferramentas. Para criar uma nova: coloque um .py em backend/plugins/ usando @tool (veja docs/FERRAMENTAS.md)."""
import asyncio
import importlib.util
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from app.db.models import Setting, SessionLocal
from app.tools.util import ToolError

log = logging.getLogger("jarvis.tools")
REGISTRY: dict[str, "Tool"] = {}
__all__ = ["Tool", "ToolError", "tool", "REGISTRY", "is_enabled", "set_enabled", "enabled_tools", "execute", "load_plugins"]


@dataclass
class Tool:
    name: str
    description: str
    input_schema: dict
    run: Callable[[dict], str]
    risk: str = "low"  # low = automática; sensitive = exige confirmação (bloqueada até a Etapa 8)


def tool(name: str, description: str, schema: dict, risk: str = "low"):
    def deco(fn):
        REGISTRY[name] = Tool(name, description, schema, fn, risk)
        return fn
    return deco


def is_enabled(name: str) -> bool:
    t = REGISTRY.get(name)
    if not t:
        return False
    with SessionLocal() as db:
        row = db.get(Setting, f"tool:{name}")
    return (t.risk == "low") if row is None else row.value == "1"


def set_enabled(name: str, enabled: bool) -> None:
    with SessionLocal() as db:
        row = db.get(Setting, f"tool:{name}") or Setting(key=f"tool:{name}", value="1")
        row.value = "1" if enabled else "0"
        db.add(row); db.commit()


def enabled_tools() -> list[Tool]:
    return [t for t in REGISTRY.values() if t.risk == "low" and is_enabled(t.name)]


async def execute(name: str, args: dict) -> str:
    t = REGISTRY.get(name)
    if not t or not is_enabled(name):
        return f"ERRO: a ferramenta '{name}' não está disponível."
    if t.risk != "low":
        return "AÇÃO BLOQUEADA: exige confirmação do usuário, ainda não disponível."
    if not isinstance(args, dict):
        return "ERRO: argumentos inválidos."
    missing = [k for k in t.input_schema.get("required", []) if k not in args]
    if missing:
        return f"ERRO: faltam argumentos: {', '.join(missing)}"
    try:
        out = await asyncio.wait_for(asyncio.to_thread(t.run, args), 30)
    except ToolError as e:
        return f"ERRO: {e}"
    except asyncio.TimeoutError:
        return "ERRO: a ferramenta demorou demais."
    except Exception:
        log.exception("Falha na ferramenta %s", name)
        return "ERRO: falha interna na ferramenta."
    log.info("ferramenta %s executada", name)
    return str(out)[:8000]


def load_plugins(directory: Path) -> list[str]:
    loaded = []
    for f in sorted(Path(directory).glob("*.py")):
        if f.name.startswith("_"):
            continue
        try:
            spec = importlib.util.spec_from_file_location(f"jarvis_plugin_{f.stem}", f)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            loaded.append(f.name)
        except Exception:
            log.exception("Plugin %s falhou ao carregar", f.name)
    return loaded
