from app.tools import builtin  # noqa: F401  (registra as ferramentas nativas)
