"""Utilitários puros (só biblioteca padrão) das ferramentas."""
import ipaddress
import re
import socket
import unicodedata
from html.parser import HTMLParser
from pathlib import Path


class ToolError(Exception):
    """Erro esperado, com mensagem segura para mostrar ao modelo."""


def safe_path(root: Path, rel: str) -> Path:
    """Resolve `rel` dentro de `root`; recusa '..', caminhos absolutos e links que escapam."""
    root = root.resolve()
    p = (root / (rel or "")).resolve()
    if p != root and not p.is_relative_to(root):
        raise ToolError("Caminho fora da pasta de trabalho.")
    return p


def slugify(text: str) -> str:
    t = unicodedata.normalize("NFD", text.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")[:60] or "documento"


def unique_path(folder: Path, stem: str, ext: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    p, n = folder / f"{stem}.{ext}", 2
    while p.exists():
        p, n = folder / f"{stem}-{n}.{ext}", n + 1
    return p


class _Text(HTMLParser):
    def __init__(self):
        super().__init__(); self.out: list[str] = []; self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "noscript"):
            self.skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript") and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if not self.skip and data.strip():
            self.out.append(data.strip())


def html_to_text(html: str) -> str:
    p = _Text(); p.feed(html)
    return re.sub(r"\s+", " ", " ".join(p.out)).strip()


def is_private_host(host: str) -> bool:
    """True se o host resolve para endereço interno (anti-SSRF)."""
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return True
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return True
    return False
