"""Busca por relevância (TF-IDF local, sem dependências) e leitura das propostas de memória.
IMPORTANTE: isto NÃO é busca semântica por embeddings: casa palavras (sem acento, com radical curto).
Para busca semântica real, implemente um `Embedder` (Voyage, OpenAI, etc.) e pgvector no Supabase."""
import json
import math
import re
import unicodedata
from collections import Counter

STOP = set("para com uma que nao mais como dos das por sao tem ele ela seu sua meu minha voce esta isso essa esse the and mas foi ser ter muito".split())
CATEGORIES = ("preference", "info", "project", "task", "decision", "context")


def tokens(text: str) -> list[str]:
    t = unicodedata.normalize("NFD", text.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return [w[:5] for w in re.findall(r"[a-z0-9]{3,}", t) if w not in STOP]


def rank(query: str, docs: list[tuple[int, str]], k: int = 5, min_score: float = 0.2) -> list[tuple[int, float]]:
    qt = tokens(query)
    if not qt or not docs:
        return []
    toks = {i: tokens(t) for i, t in docs}
    df: Counter = Counter()
    for ts in toks.values():
        df.update(set(ts))
    n = len(docs)

    def vec(ts: list[str]) -> dict[str, float]:
        c = Counter(ts)
        return {w: c[w] * math.log(1 + n / (1 + df.get(w, 0))) for w in c}

    qv = vec(qt)
    qn = math.sqrt(sum(v * v for v in qv.values()))
    out = []
    for i, ts in toks.items():
        dv = vec(ts)
        dn = math.sqrt(sum(v * v for v in dv.values()))
        if not dn or not qn:
            continue
        s = sum(qv[w] * dv.get(w, 0.0) for w in qv) / (qn * dn)
        if s >= min_score:
            out.append((i, s))
    out.sort(key=lambda x: -x[1])
    return out[:k]


def parse_candidates(raw: str) -> list[dict]:
    """Lê a resposta JSON do modelo com candidatos a memória; ignora lixo."""
    a, b = raw.find("["), raw.rfind("]")
    if a < 0 or b < a:
        return []
    try:
        data = json.loads(raw[a : b + 1])
    except ValueError:
        return []
    out = []
    for it in data if isinstance(data, list) else []:
        if not isinstance(it, dict) or not isinstance(it.get("content"), str):
            continue
        c = it["content"].strip()
        if not 3 <= len(c) <= 300:
            continue
        kind = it.get("kind") if it.get("kind") in ("short", "long") else "long"
        cat = it.get("category") if it.get("category") in CATEGORIES else "info"
        out.append({"content": c, "kind": kind, "category": cat})
    return out
