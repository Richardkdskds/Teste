# JARVIS

Assistente pessoal de IA (voz, texto, memória, agente autônomo).

## Estrutura
- `frontend/` Next.js + TypeScript + Tailwind (Etapa 2), com PWA instalável (Etapa 9)
- `backend/app/` FastAPI: `api`, `agent`, `memory`, `voice`, `tools`, `automation`, `security` (Etapa 8), `db`, `core`
- `backend/tests/` testes, incluindo segurança e integração ponta a ponta (Etapa 10)
- `scripts/windows/` instalação e inicialização no Windows (Etapa 9)
- `config/` configurações, `docs/` documentação

## Rodar o backend (Etapa 1)
```
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp ../.env.example .env
uvicorn app.main:app --reload
pytest
```
Abra http://localhost:8000/health

## Banco
Padrão: SQLite local. Para Supabase, use a string Postgres no `DATABASE_URL`.

## Status
Todas as 10 etapas implementadas (veja `docs/PROGRESSO.md` para detalhes e pendências conhecidas — nada foi executado no ambiente em que este código foi escrito, por falta de internet para instalar dependências).

## Frontend (Etapa 2)
```
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```
Abra http://localhost:3000 (voz funciona melhor no Chrome/Edge). O backend precisa estar rodando para o indicador ficar online.
Respostas da IA entram na Etapa 3; antes disso o Jarvis só responde à saudação "você está aí?" e informa o status.

## Conectar a Claude API (Etapa 3)
1. Crie uma chave em https://console.anthropic.com e coloque em `backend/.env` como `ANTHROPIC_API_KEY=...`
2. Reinicie o backend. O indicador "IA configurada" na interface fica verde.
3. A conversa usa WebSocket (`/ws/chat`) com respostas em streaming. A chave nunca vai para o navegador.
Testes: `cd backend && pytest` (usam um modelo falso, não gastam crédito).

## Voz (Etapa 4)
Veja `docs/VOZ.md` para recursos e limitações (palavra-chave só com a página aberta).

## Memória (Etapa 5)
Veja `docs/MEMORIA.md`. Se você já rodou a Etapa 1 e o backend acusar erro de tabela, apague `backend/jarvis.db` (esquema mudou).

## Agente e missões (Etapa 6)
Veja `docs/AGENTE.md`. O esquema do banco mudou de novo: se der erro de coluna, apague `backend/jarvis.db`.

## Ferramentas (Etapa 7)
Veja `docs/FERRAMENTAS.md`. Dependências novas: `pip install -r requirements.txt`. Esquema do banco mudou: se der erro de tabela, apague `backend/jarvis.db`.

## Segurança (Etapa 8)
Veja `docs/SEGURANCA.md`. Por padrão (sem `JARVIS_ADMIN_PASSWORD`), a autenticação fica desligada — bom para desenvolver sozinho na sua máquina. Antes de expor o Jarvis em rede, defina `JARVIS_ADMIN_PASSWORD` e `JARVIS_SECRET_KEY` em `backend/.env`; a interface vai pedir a senha e guardar um token temporário.

## Android e Windows (Etapa 9)
Veja `docs/ANDROID_WINDOWS.md`.
- **Windows**: `scripts\windows\install.bat` instala tudo, `scripts\windows\start.bat` sobe backend + frontend e abre o navegador.
- **Android**: o frontend é um PWA instalável (Chrome → ⋮ → "Adicionar à tela inicial") graças a `frontend/public/manifest.json` e `frontend/public/sw.js`.

## Testes finais (Etapa 10)
```
cd backend && pytest
```
Além dos testes por módulo, `tests/test_security.py` cobre login/token/rate-limit e `tests/test_integration_smoke.py` percorre o fluxo completo (memória, tarefas, missão e chat) com a autenticação ligada. Veja `docs/PROGRESSO.md` para o estado final e as pendências conhecidas (nada neste repositório foi de fato executado no ambiente em que foi escrito, por falta de internet para instalar as dependências).
