@echo off
REM Atalho de duplo clique: chama o start.ps1 permitindo execução de script só para este processo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
pause
