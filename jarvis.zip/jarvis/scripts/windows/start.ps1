# Inicia o backend (FastAPI/uvicorn) e o frontend (Next.js) juntos, cada um em
# sua própria janela do PowerShell, e abre o navegador quando o frontend sobe.
# Rode scripts\windows\install.ps1 uma vez antes deste script.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

if (-not (Test-Path "$root\backend\.venv")) {
  Write-Host "Backend não instalado. Rode scripts\windows\install.ps1 primeiro." -ForegroundColor Red
  exit 1
}

Write-Host "Iniciando backend em http://localhost:8000 ..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList @(
  "-NoExit", "-Command",
  "cd `"$root\backend`"; .\.venv\Scripts\Activate.ps1; uvicorn app.main:app --host 127.0.0.1 --port 8000"
)

Start-Sleep -Seconds 2

Write-Host "Iniciando frontend em http://localhost:3000 ..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList @(
  "-NoExit", "-Command",
  "cd `"$root\frontend`"; npm run dev"
)

Start-Sleep -Seconds 4
Start-Process "http://localhost:3000"

Write-Host "Jarvis iniciado. Feche as duas janelas do PowerShell para encerrar." -ForegroundColor Green
