# Instala o Jarvis no Windows: cria o venv do backend, instala dependências
# Python e Node, e prepara os arquivos .env a partir dos exemplos.
# Requisitos: Python 3.11+ e Node.js 18+ já instalados e no PATH.
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Write-Host "== Backend ==" -ForegroundColor Cyan
Push-Location "$root\backend"
if (-not (Test-Path ".venv")) { python -m venv .venv }
& ".\.venv\Scripts\pip.exe" install -r requirements.txt
if (-not (Test-Path ".env")) {
  Copy-Item "..\.env.example" ".env"
  Write-Host "Criado backend\.env — edite ANTHROPIC_API_KEY e JARVIS_ADMIN_PASSWORD antes de usar." -ForegroundColor Yellow
}
Pop-Location

Write-Host "== Frontend ==" -ForegroundColor Cyan
Push-Location "$root\frontend"
if (-not (Test-Path ".env.local")) { Copy-Item ".env.local.example" ".env.local" }
npm install
Pop-Location

Write-Host "Pronto. Use scripts\windows\start.ps1 para iniciar o Jarvis." -ForegroundColor Green
