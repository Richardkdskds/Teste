# Agente autônomo e Central de Missões

## Como funciona
1. Você descreve a missão na aba **Missões**.
2. O **planejador** cria até `JARVIS_MAX_STEPS_PER_MISSION` passos (usa suas memórias aprovadas como contexto).
3. O **executor** roda cada passo; passos marcados 🌐 usam a busca web nativa da Claude.
4. O **verificador** confere cada resultado; se reprovar, o passo é refeito uma vez com a correção indicada.
5. O **redator** monta o relatório final em Markdown. Passos que continuaram com problema são listados em vermelho.

Status por missão: objetivo, plano, etapas (com tentativas), resultado e erros. **⛔ PARAR TUDO** cancela as missões em andamento; cada missão também tem Cancelar.

## Limites de segurança
- Máx. de chamadas ao modelo por missão (`JARVIS_MAX_MODEL_CALLS_PER_MISSION`, padrão 40) e de missões simultâneas (padrão 2).
- Conteúdo da web é tratado como dado não confiável no prompt (defesa parcial; proteção completa contra prompt injection vem na Etapa 8).
- Nesta etapa o agente só pensa e pesquisa: **não** envia e-mails, não mexe em arquivos nem executa programas. Ferramentas locais e confirmações de ações sensíveis entram nas Etapas 7 e 8.

## Limitações
- A busca web exige que a ferramenta esteja habilitada na sua organização no Console da Anthropic. Sem ela, passos 🌐 falham.
- Missões rodam dentro do processo do backend. Se ele reiniciar, a missão em andamento é marcada como falha.
- Custo: uma missão pode usar até ~40 chamadas à Claude API. Acompanhe seu consumo.
- O resultado é texto na tela (sem exportar documento ainda) e missões não são criadas por voz/chat ainda, só pela aba Missões.
- Sem login (Etapa 8): não exponha o backend na internet.
