# Memória do JARVIS

- **Longo prazo**: fatos duráveis. **Curto prazo**: contexto temporário, expira em 24h. A conversa em andamento fica no histórico da conexão (últimas 20 mensagens).
- **Autorização**: o Jarvis só *sugere* memórias (status "proposed"); elas só entram nas conversas depois que você aprova. Você também pode adicionar, editar, excluir, buscar, desligar a memória ou apagar tudo (aba Memória).
- **Como o Jarvis usa**: a cada mensagem, as memórias ativas mais relevantes entram no prompt como dados (não como instruções).
- **Sugestões automáticas** usam uma chamada extra à Claude API por mensagem (curta). Desligue em "Sugerir memórias automaticamente".

## Limitações
- A busca é por relevância de palavras (TF-IDF local), **não** semântica por embeddings. "Carro" não encontra "automóvel". Para busca semântica real: implementar um provedor de embeddings e usar pgvector no Supabase.
- Sem login ainda (Etapa 8): quem alcançar o backend lê/edita a memória.
- Sem migrações: se o esquema do banco mudar em desenvolvimento, apague o `jarvis.db` (isto apaga os dados).
- Não armazene segredos (senhas, cartões) na memória; o extrator é instruído a ignorá-los, mas não é garantia.
