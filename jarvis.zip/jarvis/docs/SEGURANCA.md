# Segurança (Etapa 8)

## Como funciona
- Existe um único operador, autenticado por **uma senha de administrador**
  (`JARVIS_ADMIN_PASSWORD`), não um sistema de contas.
- No login (`POST /api/auth/login`), o backend devolve um **token assinado**
  (HMAC-SHA256 com `JARVIS_SECRET_KEY`), válido por `JARVIS_TOKEN_TTL_HOURS`
  horas (padrão: 12). Não é JWT nem depende de bibliotecas externas — é só
  `"<expira_em>.<assinatura>"`, verificado comparando a assinatura em tempo
  constante.
- Toda rota de API (`/api/missions`, `/api/memory`, `/api/tools`,
  `/api/tasks`, `/api/reminders`) exige esse token no cabeçalho
  `Authorization: Bearer <token>`. O WebSocket (`/ws/chat`) exige o token na
  query string (`?token=...`), já que o navegador não permite cabeçalhos
  customizados em WebSocket.
- `GET /health` e `GET /api/auth/status` continuam públicos (o frontend
  precisa deles antes de autenticar).

## Modo desenvolvimento (padrão)
Se `JARVIS_ADMIN_PASSWORD` estiver **vazio** (como no `.env.example` antes de
você editá-lo, e como nos testes automatizados), a autenticação fica
**desligada**: nada é bloqueado, igual às etapas 1-7. Isso é intencional,
para não quebrar o fluxo de desenvolvimento local. O backend registra um
aviso (`log.warning`) uma vez ao detectar isso.

**Antes de expor o Jarvis fora do seu computador** (rede local, internet,
etc.), defina em `backend/.env`:
```
JARVIS_ADMIN_PASSWORD=uma-senha-forte-e-só-sua
JARVIS_SECRET_KEY=$(openssl rand -hex 32)
```

## Proteções incluídas
- **Senha**: comparação em tempo constante (`hmac.compare_digest`), nunca
  comparação direta de strings.
- **Rate limit de login**: no máximo 8 tentativas por IP a cada 5 minutos
  (`app/security/rate_limit.py`); além disso, `429 Too Many Requests`.
- **CORS** restrito a `JARVIS_ALLOWED_ORIGINS` (já existia desde a Etapa 1).
- **Origem do WebSocket** verificada contra a mesma lista.
- **Cabeçalhos de resposta**: `X-Content-Type-Options: nosniff`,
  `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`.
- A chave da Anthropic (`ANTHROPIC_API_KEY`) nunca sai do backend — isso já
  valia desde a Etapa 3 e continua valendo.

## Frontend
- O token fica em `localStorage` (`jarvis_token`), nunca em cookies (evita
  CSRF; o app não usa sessão baseada em cookie).
- `frontend/app/api.ts` centraliza o envio do cabeçalho `Authorization` e
  trata respostas `401` disparando o evento `jarvis:unauthorized`, que faz a
  tela de login (`LoginGate.tsx`) reaparecer.
- Se o backend responder `auth_required: false` (modo dev), a tela de login
  é pulada automaticamente.

## O que fica de fora (propositalmente)
- Múltiplos usuários/contas — fora de escopo para um assistente pessoal de
  um operador só.
- HTTPS/TLS — é responsabilidade de onde você hospedar (proxy reverso como
  Caddy/Nginx, ou um túnel). O Jarvis não termina TLS sozinho.
- Refresh token / revogação individual — o token expira sozinho; para
  "deslogar todo mundo", troque `JARVIS_SECRET_KEY` (invalida todos os
  tokens emitidos).

## Testes
`backend/tests/test_security.py` cobre: login com senha errada/certa, acesso
negado sem token, acesso liberado com token válido, token expirado ou
adulterado, rate limit do login e o handshake do WebSocket com e sem token.
Como as etapas anteriores, esses testes **não foram executados neste
ambiente de desenvolvimento** (sem internet para instalar as dependências
Python) — rode `cd backend && pytest` para confirmar.
