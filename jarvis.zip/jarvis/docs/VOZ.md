# Voz do JARVIS

## O que funciona (navegador Chrome/Edge)
- Botão **Falar**: reconhece fala em pt-BR e encerra sozinho após o silêncio configurado (Config).
- Indicador de áudio real (nível do microfone via Web Audio).
- **Palavra-chave (modo ON)**: escuta continuamente e só envia frases que contenham "Jarvis". Pausa enquanto o Jarvis fala.
- Histórico de comandos de voz (aba Voz), guardado no navegador (localStorage).
- Voz, volume e botão Interromper.

## Limitações reais
- O modo palavra-chave **só funciona com a página aberta e em primeiro plano**. Navegadores e o Android suspendem microfone em segundo plano.
- O reconhecimento usa o serviço do navegador (no Chrome, envia o áudio ao Google). Não é offline nem privado.
- Fala interrompendo o Jarvis por voz (barge-in) não está ativa: eco do alto-falante causaria falsos disparos. Use o botão Interromper.
- Safari/iOS tem suporte limitado ao reconhecimento de fala.

## Caminho para palavra-chave em segundo plano (futuro)
Exige app nativo Android (serviço em primeiro plano + motor offline como Porcupine/openWakeWord). A arquitetura atual isola a voz em `useVoice.ts`, então o motor pode ser trocado sem mexer na interface.
