# Android e Windows (Etapa 9)

O Jarvis é web (Next.js + FastAPI), então "rodar no Android/Windows" aqui
significa duas coisas diferentes, tratadas separadamente abaixo.

## Windows — rodar o backend e o frontend como um app local
Não construímos um instalador nativo (`.exe`) nem um app Electron — isso
exigiria empacotar um runtime Python e Node inteiros, o que não cabe no
escopo deste projeto nem pôde ser testado no ambiente de desenvolvimento
(sem internet). Em vez disso, dois scripts PowerShell cuidam de instalar e
rodar tudo com um duplo clique:

1. **Pré-requisitos**: [Python 3.11+](https://www.python.org/downloads/) e
   [Node.js 18+](https://nodejs.org/) instalados, com a opção "Add to PATH"
   marcada no instalador do Python.
2. Dê duplo clique em `scripts\windows\install.bat` (uma única vez). Ele:
   - cria o ambiente virtual do backend e instala `requirements.txt`;
   - cria `backend\.env` e `frontend\.env.local` a partir dos `.example`;
   - instala as dependências do frontend (`npm install`).
3. Edite `backend\.env` e preencha pelo menos `ANTHROPIC_API_KEY`. Para expor
   o Jarvis além do seu próprio PC, defina também `JARVIS_ADMIN_PASSWORD` e
   `JARVIS_SECRET_KEY` (veja `docs/SEGURANCA.md`).
4. Dê duplo clique em `scripts\windows\start.bat`. Ele abre duas janelas do
   PowerShell (backend na porta 8000, frontend na porta 3000) e o navegador
   em `http://localhost:3000`. Para encerrar, feche as duas janelas.

Se preferir rodar manualmente, os mesmos comandos do `README.md` (seções
"Rodar o backend" e "Frontend") funcionam sem alterações no Windows — os
scripts acima só automatizam o `cd`, a ativação do venv e a abertura do
navegador.

### Caminho para um `.exe` de verdade (fora do escopo atual)
Quem quiser ir além pode empacotar o backend com `pyinstaller` (gerando um
`.exe` que embute o Python) e o frontend com `next build && next export` ou
rodando `next start` dentro de um wrapper Electron/Tauri. Isso não foi feito
aqui porque exige testar binários reais em uma máquina Windows, algo que
este ambiente de desenvolvimento não tem.

## Android — usar o Jarvis como um app instalável (PWA)
O frontend agora é um **PWA (Progressive Web App)**: `frontend/public/manifest.json`
e `frontend/public/sw.js`, registrados em `frontend/app/layout.tsx`. Isso
permite "Adicionar à tela inicial" no Chrome do Android, o que dá um ícone
próprio, abre em tela cheia (sem a barra de endereço) e mantém o app na
lista de recentes como qualquer outro.

Isso **não é** um app nativo Android (não publica na Play Store) — é a forma
realista de ter o Jarvis "instalado" no celular sem introduzir Kotlin/Java,
Android Studio ou um build system que não pode ser compilado neste ambiente
de desenvolvimento (sem internet, conforme documentado nas etapas
anteriores).

### Como instalar
1. O frontend precisa estar acessível pela rede do celular. Duas opções:
   - Mesma rede Wi-Fi: rode `npm run dev -- -H 0.0.0.0` (ou `next start -H 0.0.0.0`
     após `npm run build`) no computador, descubra o IP dele (`ipconfig`/`ifconfig`)
     e acesse `http://SEU_IP:3000` no celular. Ajuste também
     `NEXT_PUBLIC_API_URL` no `.env.local` para `http://SEU_IP:8000` e
     `JARVIS_ALLOWED_ORIGINS` no `backend/.env` para incluir
     `http://SEU_IP:3000`.
   - Ou publique o frontend e o backend em algum serviço (Vercel, Render,
     etc.) — fora do escopo deste repositório, mas compatível, já que é só
     Next.js + FastAPI padrão.
2. No Chrome do Android, abra a URL do Jarvis e toque em **⋮ → Adicionar à
   tela inicial** (ou no banner "Instalar app" se aparecer).
3. Primeiro acesso: se `JARVIS_ADMIN_PASSWORD` estiver definido, a tela de
   login pedirá a senha (veja `docs/SEGURANCA.md`).

### Limitações conhecidas no Android
- A palavra-chave de voz só funciona com a página aberta e em primeiro
  plano — veja `docs/VOZ.md` (isso já valia na Etapa 4, antes deste PWA).
- O reconhecimento de voz do navegador no Android funciona melhor no Chrome;
  outros navegadores podem não suportar `webkitSpeechRecognition`.
- Como o app roda em HTTP na rede local (sem HTTPS), alguns recursos do
  navegador podem ficar restritos. Para uso sério fora da sua rede local,
  recomenda-se um domínio com HTTPS (ex.: via Caddy/Nginx) na frente do
  backend e do frontend.
