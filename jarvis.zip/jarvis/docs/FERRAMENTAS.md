# Ferramentas e automações

As missões (aba Missões) podem usar as ferramentas abaixo. Você liga/desliga cada uma na aba **Ferramentas**. Todas são de **baixo risco** e rodam sem pedir confirmação.

| Ferramenta | O que faz |
|---|---|
| list_files, read_file | Lista e lê arquivos de texto da **pasta de trabalho** (`JARVIS_WORKSPACE`) |
| write_file, make_folder, move_file | Cria arquivos NOVOS, pastas e move/renomeia dentro da pasta. **Nunca sobrescreve nem exclui** |
| read_pdf | Extrai texto de PDF (até 20 páginas; PDF escaneado não funciona, sem OCR) |
| create_document | Cria `.md` ou `.docx` simples em `documentos/` |
| add_task, list_tasks, complete_task | Tarefas (também na aba Ferramentas) |
| create_reminder, list_reminders | Lembretes: o Jarvis avisa por voz e tela **com o app aberto** |
| fetch_page | Abre páginas **somente de domínios que você listar** em `JARVIS_ALLOWED_DOMAINS` (vazio = desligado). Bloqueia endereços internos e redirecionamentos |
| web_search (nativa) | Busca na internet da Claude, usada nos passos 🌐 (precisa estar habilitada no Console da Anthropic) |

Arquivos nunca saem da pasta de trabalho (testado contra `../`, caminho absoluto e links simbólicos).

## Criar uma ferramenta nova (sem reconstruir o app)
Copie `backend/plugins/exemplo_hora.py`, mude o nome e a função e **reinicie o backend**. Ela aparece sozinha na aba Ferramentas. Ferramentas com `risk="sensitive"` ficam bloqueadas até a Etapa 8 (confirmações).

## O que NÃO está implementado ainda
- Envio de e-mail, exclusão de arquivos, execução de scripts, instalação de programas, compras: exigem o sistema de confirmação (Etapa 8).
- Controle do computador (abrir apps, automação do Windows) e do Android: Etapa 9.
- Calendário (Google Calendar etc.) e integrações com APIs externas: não feitos. Tarefas e lembretes internos existem.
- As ferramentas só são usadas por **missões**, não pela conversa por voz/chat. Para criar um lembrete pelo Jarvis, peça como missão.
- Conteúdo de páginas e PDFs é tratado como dado não confiável no prompt (defesa parcial; proteção completa na Etapa 8).
