- [x] Etapa 1 Arquitetura
- [x] Etapa 2 Interface (não compilada, sem internet no ambiente)
- [x] Etapa 3 Claude API (WebSocket com streaming; não testada contra a API real)
- [x] Etapa 4 Voz (não compilada nem testada em navegador)
- [x] Etapa 5 Memória (busca por palavras; testes não executados, sem internet)
- [x] Etapa 6 Agente (apenas raciocínio + busca web; testes não executados, sem internet)
- [x] Etapa 7 Ferramentas (só baixo risco; testes não executados, sem internet)
- [x] Etapa 8 Segurança (login + token assinado, rate limit; ver docs/SEGURANCA.md; testes não executados, sem internet)
- [x] Etapa 9 Android (PWA instalável) / Windows (scripts de instalação e início); ver docs/ANDROID_WINDOWS.md. Não testado em dispositivo real.
- [x] Etapa 10 Testes finais (test_security.py, test_integration_smoke.py cobrindo o fluxo completo com autenticação; nenhum teste deste projeto foi executado neste ambiente — sem internet para `pip install`/`npm install`)

## Pendências conhecidas (fora do escopo das 10 etapas)
- Nenhum teste automatizado foi de fato **executado** neste ambiente de
  desenvolvimento (sem acesso à rede para instalar dependências). Antes de
  usar em produção, rode `cd backend && pytest` e confirme que os 9 arquivos
  de teste passam.
- Sem HTTPS nativo — use um proxy reverso se for expor o Jarvis fora da sua
  rede local (ver docs/SEGURANCA.md e docs/ANDROID_WINDOWS.md).
- Sem instalador `.exe` nativo para Windows nem publicação na Play Store para
  Android — ambos documentados como caminhos possíveis, não implementados.
- Memória usa busca por palavras-chave (Etapa 5), não embeddings semânticos.
